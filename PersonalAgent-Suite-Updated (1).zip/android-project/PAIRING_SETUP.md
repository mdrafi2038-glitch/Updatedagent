# Consent-based Client/Admin pairing

1. Add the correct Firebase google-services.json to the Android app module.
2. In Firebase Authentication, enable Anonymous sign-in.
3. Create a Realtime Database for this Firebase project.
4. Apply database.rules.json in Realtime Database Rules. Rules require authentication; each request uses a random 128-bit token that must be deliberately shared.
5. On Client, generate a code. Enter it on Admin. The Client owner must press Approve this Admin.
6. Pairing expires after 10 minutes. It exchanges device name/model and Android version only; it does not transmit GPS, camera data or remote commands.

Do not use public read/write rules. Firebase configuration and rules must be deployed before cross-phone pairing works.
