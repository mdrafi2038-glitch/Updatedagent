package com.example.lock

import android.app.ActivityManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.example.receiver.AgentDeviceAdminReceiver
import com.example.ui.theme.MyApplicationTheme

/**
 * Fullscreen Lockdown Restriction Overlay.
 * Freezes system navigation (Back button, Home button, Recent apps switcher)
 * and collapses the notification shade / status bar expansion to prevent bypass.
 */
class LockActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure aggressive window flags to stay on top of lockscreen and disable system dialogs
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }

        // Hide system bars and enable immersive sticky mode
        applyImmersiveStickyMode()

        // Freeze Back button via modern OnBackPressedDispatcher
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                onNavigationBlocked("Back")
            }
        })

        // Attempt LockTask mode (Kiosk pinning) if device owner or permitted
        tryLockTaskMode()

        setContent {
            MyApplicationTheme(darkTheme = true) {
                RestrictionScreen(
                    onRestart = { performDeviceRestart() },
                    onTurnOff = { performDevicePowerOff() }
                )
            }
        }
    }

    private fun applyImmersiveStickyMode() {
        val windowInsetsController = WindowCompat.getInsetsController(window, window.decorView)
        windowInsetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        windowInsetsController.hide(WindowInsetsCompat.Type.systemBars())

        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
        )
    }

    /**
     * Intercepts loss of window focus (e.g. when user tries to pull down notification shade
     * or press system recent apps). Collapses panels and re-asserts immersive lockdown.
     */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) {
            // Collapse notification shade and close system dialogs immediately
            collapseNotificationShade()
            applyImmersiveStickyMode()
        }
    }

    private fun collapseNotificationShade() {
        try {
            @Suppress("DEPRECATION")
            val closeDialog = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
            sendBroadcast(closeDialog)
        } catch (_: Exception) {}

        try {
            val statusBarService = getSystemService("statusbar")
            val statusBarManager = Class.forName("android.app.StatusBarManager")
            val collapse = statusBarManager.getMethod("collapsePanels")
            collapse.invoke(statusBarService)
        } catch (_: Exception) {}
    }

    private fun tryLockTaskMode() {
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (dpm.isLockTaskPermitted(packageName)) {
                    startLockTask()
                }
            }
        } catch (_: Exception) {}
    }

    /**
     * Intercept physical and virtual key presses (Back, Home, Recent Apps, Volume).
     * Prevents volume reduction and navigation escape during lockdown.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                onNavigationBlocked("Back")
                return true
            }
            KeyEvent.KEYCODE_HOME -> {
                onNavigationBlocked("Home")
                collapseNotificationShade()
                return true
            }
            KeyEvent.KEYCODE_APP_SWITCH -> {
                onNavigationBlocked("Recents / App Switcher")
                collapseNotificationShade()
                return true
            }
            KeyEvent.KEYCODE_MENU -> {
                onNavigationBlocked("Menu")
                return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_MUTE -> {
                // Consume volume key presses so siren or alarm volume cannot be lowered
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    @Deprecated("Deprecated in Java; retained for legacy Android compatibility")
    override fun onBackPressed() {
        onNavigationBlocked("Back")
    }

    private fun onNavigationBlocked(buttonName: String) {
        collapseNotificationShade()
        applyImmersiveStickyMode()
        Toast.makeText(
            this,
            "🔒 Navigation Frozen: $buttonName button is locked by Personal Agent.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun performDeviceRestart() {
        Toast.makeText(this, "Rebooting device...", Toast.LENGTH_SHORT).show()

        // 1. DevicePolicyManager hardware reboot (Official Device Owner API)
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val adminComponent = ComponentName(this, AgentDeviceAdminReceiver::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && dpm.isDeviceOwnerApp(packageName)) {
                dpm.reboot(adminComponent)
                return
            }
        } catch (_: Exception) {}

        // 2. PowerManager hardware reboot
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            pm?.reboot(null)
            return
        } catch (_: Exception) {}

        // 3. IPowerManager ServiceManager reflection reboot
        try {
            val smClass = Class.forName("android.os.ServiceManager")
            val getService = smClass.getMethod("getService", String::class.java)
            val powerBinder = getService.invoke(null, Context.POWER_SERVICE) as android.os.IBinder
            val iPowerClass = Class.forName("android.os.IPowerManager\$Stub")
            val asInterface = iPowerClass.getMethod("asInterface", android.os.IBinder::class.java)
            val powerService = asInterface.invoke(null, powerBinder)
            val rebootMethod = powerService.javaClass.getMethod(
                "reboot",
                Boolean::class.javaPrimitiveType,
                String::class.java,
                Boolean::class.javaPrimitiveType
            )
            rebootMethod.invoke(powerService, false, null, false)
            return
        } catch (_: Exception) {}

        // 4. Root / Superuser shell reboot execution
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot"))
            proc.waitFor()
            return
        } catch (_: Exception) {}

        // 5. Direct shell reboot execution
        try {
            Runtime.getRuntime().exec("reboot")
            return
        } catch (_: Exception) {}

        Toast.makeText(
            this,
            "Reboot requires Device Owner setup (adb shell dpm set-device-owner ...) or phone power key.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun performDevicePowerOff() {
        Toast.makeText(this, "Powering off device...", Toast.LENGTH_SHORT).show()

        // 1. Android official shutdown request broadcast / intent
        try {
            val shutdownIntent = Intent("android.intent.action.ACTION_REQUEST_SHUTDOWN").apply {
                putExtra("android.intent.extra.KEY_CONFIRM", false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(shutdownIntent)
            return
        } catch (_: Exception) {}

        // 2. IPowerManager ServiceManager reflection shutdown
        try {
            val smClass = Class.forName("android.os.ServiceManager")
            val getService = smClass.getMethod("getService", String::class.java)
            val powerBinder = getService.invoke(null, Context.POWER_SERVICE) as android.os.IBinder
            val iPowerClass = Class.forName("android.os.IPowerManager\$Stub")
            val asInterface = iPowerClass.getMethod("asInterface", android.os.IBinder::class.java)
            val powerService = asInterface.invoke(null, powerBinder)
            val shutdownMethod = powerService.javaClass.getMethod(
                "shutdown",
                Boolean::class.javaPrimitiveType,
                String::class.java,
                Boolean::class.javaPrimitiveType
            )
            shutdownMethod.invoke(powerService, false, null, false)
            return
        } catch (_: Exception) {}

        // 3. Root / Superuser shell shutdown execution (reboot -p)
        try {
            val proc = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot -p"))
            proc.waitFor()
            return
        } catch (_: Exception) {}

        // 4. Try internal shutdown activity
        try {
            val internalIntent = Intent().apply {
                component = ComponentName("com.android.internal.app", "com.android.internal.app.ShutdownActivity")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(internalIntent)
            return
        } catch (_: Exception) {}

        Toast.makeText(
            this,
            "Hardware power-off requires Device Owner, Root, or long-pressing physical power button.",
            Toast.LENGTH_LONG
        ).show()
    }
}

@Composable
private fun RestrictionScreen(onRestart: () -> Unit, onTurnOff: () -> Unit) {
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF070B14)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF070B14))
                .padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Lock Badge
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .background(Color(0x26EF4444), CircleShape)
                    .border(1.5.dp, Color(0x66EF4444), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Restricted Lock",
                    tint = Color(0xFFEF4444),
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // English Text (As requested)
            Text(
                text = "your device is restricted please turn off your device",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 28.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Bangla Text (As requested)
            Text(
                text = "আপনার ডিভাইসটি সীমাবদ্ধ করা হয়েছে অনুগ্রহ করে আপনার ডিভাইসটি বন্ধ করুন",
                color = Color(0xFFCBD5E1),
                fontSize = 17.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                lineHeight = 26.sp
            )

            Spacer(modifier = Modifier.height(36.dp))

            // Restart Button (Calls real reboot)
            Button(
                onClick = onRestart,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2563EB))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Restart", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Power Off Button (Calls real power off directly)
            OutlinedButton(
                onClick = onTurnOff,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF334155))
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.PowerSettingsNew, contentDescription = null, tint = Color(0xFFEF4444))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Power off", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
            }
        }
    }
}

