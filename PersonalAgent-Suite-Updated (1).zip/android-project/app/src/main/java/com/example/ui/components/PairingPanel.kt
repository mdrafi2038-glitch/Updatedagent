package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.manager.PairingRepository
import com.example.manager.SecurityRepository
import com.example.model.ManagedDevice
import com.example.ui.theme.*
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.ValueEventListener

@Composable
fun PairingPanel(isAdmin: Boolean) {
    val context = LocalContext.current
    var code by remember { mutableStateOf("") }
    var activeToken by remember {
        mutableStateOf(context.getSharedPreferences("agent_pairing", 0).getString(if (isAdmin) "admin_token" else "client_token", "") ?: "")
    }
    var status by remember { mutableStateOf("Not connected") }
    var error by remember { mutableStateOf("") }
    var requested by remember { mutableStateOf(false) }
    var paired by remember { mutableStateOf(false) }
    var deviceName by remember { mutableStateOf("Client device") }
    var busy by remember { mutableStateOf(false) }
    var accountEmail by remember { mutableStateOf("") }
    var accountPassword by remember { mutableStateOf("") }
    var createAccount by remember { mutableStateOf(false) }
    var accountStatus by remember { mutableStateOf("") }

    DisposableEffect(activeToken, isAdmin) {
        var listener: ValueEventListener? = null
        if (activeToken.isNotBlank()) listener = PairingRepository.listen(activeToken, { snap: DataSnapshot ->
            val created = snap.child("createdAt").getValue(Long::class.java) ?: 0L
            paired = snap.child("approved").getValue(Boolean::class.java) == true
            if (!snap.exists() || snap.child("revoked").getValue(Boolean::class.java) == true ||
                (!paired && System.currentTimeMillis() - created > 600000L)) {
                status = if (snap.child("revoked").getValue(Boolean::class.java) == true)
                    "Old code replaced. Generate a new code."
                else "Pairing code expired. Generate a new code."
                requested = false
            } else {
                deviceName = snap.child("deviceName").getValue(String::class.java) ?: "Client device"
                requested = snap.child("adminRequestedAt").exists()
                status = if (paired) "Permanently paired (until owner unpairs): " + deviceName
                    else if (requested && !isAdmin) "Admin requests pairing. Review and approve below."
                    else "Waiting for Client owner approval"
                if (paired && isAdmin) {
                    SecurityRepository.setPairedDevice(
                        ManagedDevice(
                            deviceId = activeToken,
                            deviceName = deviceName,
                            model = snap.child("model").getValue(String::class.java) ?: deviceName,
                            osVersion = snap.child("osVersion").getValue(String::class.java) ?: "Android",
                            batteryPercent = 0,
                            isOnline = true,
                            isProtected = false,
                            lastSeenTimestamp = System.currentTimeMillis()
                        )
                    )
                }
            }
        }, { error = it })
        onDispose { PairingRepository.remove(activeToken, listener) }
    }

    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CyberNavyDark)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(if (isAdmin) "PAIR A CLIENT" else "DEVICE PAIRING", color = CyberCyanPrimary, fontWeight = FontWeight.Bold)
            Text("FIREBASE ACCOUNT", color = CyberCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            OutlinedTextField(
                value = accountEmail,
                onValueChange = { accountEmail = it },
                label = { Text("Email / username") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = accountPassword,
                onValueChange = { accountPassword = it },
                label = { Text("Password (6+ characters)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { createAccount = false }, modifier = Modifier.weight(1f)) {
                    Text(if (!createAccount) "✓ Login" else "Login")
                }
                OutlinedButton(onClick = { createAccount = true }, modifier = Modifier.weight(1f)) {
                    Text(if (createAccount) "✓ Create" else "Create account")
                }
            }
            Button(onClick = {
                busy = true; accountStatus = ""
                PairingRepository.authenticateAccount(accountEmail, accountPassword, createAccount) { uid, message ->
                    busy = false
                    accountStatus = if (uid != null) "Account connected. UID: " + uid.take(8) else (message ?: "Account login failed")
                }
            }, enabled = !busy && accountEmail.isNotBlank() && accountPassword.length >= 6, modifier = Modifier.fillMaxWidth()) {
                Text(if (busy) "Signing in…" else if (createAccount) "Create Firebase account" else "Login with Firebase account")
            }
            if (accountStatus.isNotBlank()) Text(accountStatus, color = CyberTextSecondary, fontSize = 12.sp)

            Text(
                if (isAdmin) "Enter the one-time code shown by Client. Client owner approval is required."
                else "Generate a pairing code. After approval, this pairing stays saved until the Client owner replaces it.",
                color = CyberTextSecondary, fontSize = 12.sp
            )
            if (!isAdmin && !paired) {
                Button(onClick = {
                    busy = true; error = ""
                    val oldToken = activeToken
                    if (oldToken.isNotBlank()) PairingRepository.revoke(context, oldToken)
                    PairingRepository.create(context) { token, message ->
                        busy = false
                        if (token != null) {
                            activeToken = token
                            requested = false
                            status = "New code generated. Previous code is invalid. Share this code with Admin."
                        } else error = message ?: "Pairing failed"
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Creating…" else if (activeToken.isBlank()) "Generate pairing code" else "Generate new code")
                }
            }
            if (isAdmin && !paired) {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it.filter(Char::isLetterOrDigit).uppercase().take(8) },
                    label = { Text("8-character pairing code") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(onClick = {
                    busy = true; error = ""
                    PairingRepository.request(code) { token, message ->
                        busy = false
                        if (token != null) {
                            activeToken = token
                            context.getSharedPreferences("agent_pairing", 0).edit().putString("admin_token", token).apply()
                            status = "Request sent. Waiting for Client approval."
                        }
                        else error = message ?: "Could not request pairing"
                    }
                }, enabled = !busy && code.length == 8, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Sending…" else "Request pairing")
                }
            }
            if (!isAdmin && activeToken.isNotBlank()) {
                Text("Code expires in 10 minutes until approved:", color = CyberWarningAmber, fontWeight = FontWeight.Bold)
                Text(activeToken, color = CyberWarningAmber, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                if (requested && !paired) Button(onClick = {
                    busy = true
                    PairingRepository.approve(activeToken) { message ->
                        busy = false
                        if (message == null) status = "Pairing approved" else error = message
                    }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                    Text(if (busy) "Approving…" else "Approve this Admin")
                }
            }
            Text(status, color = CyberTextSecondary, fontSize = 12.sp)
            if (error.isNotBlank()) Text(error, color = CyberWarningAmber, fontSize = 12.sp)
            if (paired && isAdmin) Text(
                "Consent-based identity pairing only. Remote commands, GPS and camera data are not sent by this pairing flow.",
                color = CyberTextSecondary, fontSize = 11.sp
            )
        }
    }
}
