package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
  primary = CyberCyanPrimary,
  onPrimary = CyberCyanOnPrimary,
  primaryContainer = CyberCyanContainer,
  onPrimaryContainer = Color(0xFFE0FBFC),
  secondary = CyberShieldSecondary,
  onSecondary = Color(0xFF082F49),
  secondaryContainer = CyberShieldContainer,
  onSecondaryContainer = Color(0xFFBAE6FD),
  tertiary = CyberSuccessGreen,
  onTertiary = Color(0xFF003822),
  background = CyberNavyDark,
  onBackground = CyberTextPrimary,
  surface = CyberSurfaceDark,
  onSurface = CyberTextPrimary,
  surfaceVariant = CyberSurfaceVariantDark,
  onSurfaceVariant = CyberTextSecondary,
  outline = CyberBorderDark,
  error = CyberAlertCrimson,
  onError = Color.White
)

private val LightColorScheme = lightColorScheme(
  primary = CyberPrimaryLight,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0F2FE),
  onPrimaryContainer = Color(0xFF0369A1),
  secondary = Color(0xFF0284C7),
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFE2E8F0),
  onSecondaryContainer = Color(0xFF1E293B),
  tertiary = CyberSuccessGreen,
  onTertiary = Color.White,
  background = CyberSurfaceLight,
  onBackground = Color(0xFF0F172A),
  surface = Color.White,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = CyberSurfaceVariantLight,
  onSurfaceVariant = Color(0xFF475569),
  outline = Color(0xFFCBD5E1),
  error = CyberAlertCrimson,
  onError = Color.White
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to sleek cybersecurity dark theme for high-tech aesthetic
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> DarkColorScheme
    else -> LightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
