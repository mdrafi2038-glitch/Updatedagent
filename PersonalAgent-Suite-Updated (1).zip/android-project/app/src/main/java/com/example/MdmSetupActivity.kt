package com.example

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MdmSetupActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "MDM Setup"
        dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        admin = ComponentName(this, PersonalAgentAdminReceiver::class.java)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 40, 40, 40)
        }
        status = TextView(this).apply { textSize = 16f }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Enable Device Admin"
            setOnClickListener {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).putExtra(
                    DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin
                ).putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Enable Personal Agent device management on this phone. You can revoke it in Android settings."))
            }
        })
        layout.addView(Button(this).apply {
            text = "Clear Background (choose app)"
            setOnClickListener { startActivity(Intent(this@MdmSetupActivity, BackgroundClearActivity::class.java)) }
        })
        layout.addView(Button(this).apply {
            text = "Open Android Settings"
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "\nDevice Owner setup requires Android enterprise provisioning, usually during initial setup after a factory reset. Enabling Device Admin alone is not Device Owner."
            textSize = 14f
        })
        setContentView(layout)
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun updateStatus() {
        val isAdmin = dpm.isAdminActive(admin)
        val isOwner = dpm.isDeviceOwnerApp(packageName)
        status.text = "Personal Agent MDM status\n\nDevice Admin: " +
            (if (isAdmin) "Enabled" else "Not enabled") +
            "\nDevice Owner: " + (if (isOwner) "Active" else "Not provisioned") +
            "\n\nAndroid version: " + android.os.Build.VERSION.RELEASE +
            "\nPackage: " + packageName
    }
}
