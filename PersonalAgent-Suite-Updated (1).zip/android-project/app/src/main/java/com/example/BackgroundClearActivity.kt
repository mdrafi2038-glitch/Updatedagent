package com.example

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import com.example.service.AgentService
import com.google.firebase.database.FirebaseDatabase

class BackgroundClearActivity : Activity() {

    private data class AppItem(val packageName: String, val label: String)

    private lateinit var selectedAppText: TextView
    private lateinit var statusText: TextView
    private lateinit var listView: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Clear Background"

        val prefs = getSharedPreferences("background_clear_prefs", Context.MODE_PRIVATE)
        var savedPackage = prefs.getString("selected_package", "") ?: ""
        var savedLabel = prefs.getString("selected_label", "") ?: ""

        // Query installed applications that Android allows this app to enumerate
        val apps = packageManager.getInstalledApplications(0)
            .filter { it.packageName != packageName }
            .map { AppItem(it.packageName, packageManager.getApplicationLabel(it).toString()) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }

        // Sync saved selection to Firebase on launch if paired
        val clientToken = getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("client_token", "") ?: ""
        if (clientToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$")) && savedPackage.isNotBlank()) {
            try {
                FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference
                    .child("clientSelectedApps").child(clientToken)
                    .updateChildren(mapOf(
                        "packageName" to savedPackage,
                        "appName" to (savedLabel.ifBlank { savedPackage }),
                        "updatedAt" to System.currentTimeMillis()
                    ))
            } catch (_: Exception) {}
        }

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0F19"))
            setPadding(32, 32, 32, 32)
        }

        val headerText = TextView(this).apply {
            text = "TARGET APPLICATION FOR BACKGROUND CLEAR"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 8)
        }
        rootLayout.addView(headerText)

        selectedAppText = TextView(this).apply {
            text = if (savedPackage.isNotBlank()) {
                "Selected: ${savedLabel.ifBlank { savedPackage }}\n($savedPackage)"
            } else {
                "No target application selected yet. Tap an app below to select."
            }
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, 16)
        }
        rootLayout.addView(selectedAppText)

        val clearButton = Button(this).apply {
            text = "Clear Background (Selected App)"
            setBackgroundColor(Color.parseColor("#00E5FF"))
            setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener {
                val pkg = prefs.getString("selected_package", "") ?: ""
                val label = prefs.getString("selected_label", "") ?: pkg
                if (pkg.isBlank()) {
                    Toast.makeText(this@BackgroundClearActivity, "Please select an application below first.", Toast.LENGTH_SHORT).show()
                } else {
                    try {
                        // Standard Build 64 behavior: request clearing the target app's background processes
                        val manager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                        manager.killBackgroundProcesses(pkg)
                        val msg = "Background-process clear requested for $label ($pkg). Cached background processes cleared via ActivityManager.killBackgroundProcesses."
                        statusText.text = msg
                        Toast.makeText(this@BackgroundClearActivity, msg, Toast.LENGTH_LONG).show()
                    } catch (e: Exception) {
                        val errMsg = "Could not request background clear: ${e.message}"
                        statusText.text = errMsg
                        Toast.makeText(this@BackgroundClearActivity, errMsg, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
        rootLayout.addView(clearButton)

        statusText = TextView(this).apply {
            text = "Note: Standard Android permissions clear cached background work. The operating system does not permit third-party apps to Force Stop other applications."
            setTextColor(Color.parseColor("#8E9AA8"))
            textSize = 11f
            setPadding(0, 16, 0, 16)
        }
        rootLayout.addView(statusText)

        val listTitle = TextView(this).apply {
            text = "CHOOSE APPLICATION (${apps.size} INSTALLED)"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 8, 0, 8)
        }
        rootLayout.addView(listTitle)

        listView = ListView(this).apply {
            choiceMode = ListView.CHOICE_MODE_SINGLE
            divider = null
        }

        fun updateListAdapter() {
            val currentPkg = prefs.getString("selected_package", "") ?: ""
            listView.adapter = object : ArrayAdapter<AppItem>(this, android.R.layout.simple_list_item_2, android.R.id.text1, apps) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val view = super.getView(position, convertView, parent)
                    val text1 = view.findViewById<TextView>(android.R.id.text1)
                    val text2 = view.findViewById<TextView>(android.R.id.text2)
                    val item = getItem(position)
                    if (item != null) {
                        val isSelected = item.packageName == currentPkg
                        text1.text = item.label + (if (isSelected) "  [SELECTED]" else "")
                        text1.setTextColor(if (isSelected) Color.parseColor("#00E5FF") else Color.WHITE)
                        text1.typeface = if (isSelected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
                        text2.text = item.packageName
                        text2.setTextColor(Color.parseColor("#8E9AA8"))
                    }
                    return view
                }
            }
            val idx = apps.indexOfFirst { it.packageName == currentPkg }
            if (idx >= 0) listView.setItemChecked(idx, true)
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val chosen = apps[position]
            prefs.edit()
                .putString("selected_package", chosen.packageName)
                .putString("selected_label", chosen.label)
                .apply()

            val token = getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("client_token", "") ?: ""
            if (token.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
                try {
                    FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference
                        .child("clientSelectedApps").child(token)
                        .setValue(mapOf(
                            "packageName" to chosen.packageName,
                            "appName" to chosen.label,
                            "updatedAt" to System.currentTimeMillis()
                        ))
                } catch (_: Exception) {}
            }

            selectedAppText.text = "Selected: ${chosen.label}\n(${chosen.packageName})"
            statusText.text = "Target saved: ${chosen.label}. Admin app is synced."
            Toast.makeText(this, "Target application saved: ${chosen.label}", Toast.LENGTH_SHORT).show()
            updateListAdapter()
        }

        updateListAdapter()
        rootLayout.addView(listView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(rootLayout)
    }
}
