package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.manager.SecurityRepository
import com.example.manager.AgentCommandHandler
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DataSnapshot
import com.example.manager.SirenManager
import com.example.manager.TelemetryManager
import com.example.model.EventSeverity
import com.example.model.EventType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class AgentService : Service(), SensorEventListener {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)

    private lateinit var telemetryManager: TelemetryManager
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var remoteCommandRef: DatabaseReference? = null
    private var remoteCommandListener: ChildEventListener? = null
    private var telemetryJob: Job? = null
    @Volatile private var backgroundTasksCleared = false

    private var lastAcceleration = 0f
    private var currentAcceleration = SensorManager.GRAVITY_EARTH
    private var shakeThreshold = 14f

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_POWER_DISCONNECTED) {
                val settings = SecurityRepository.settings.value
                if (settings.antiTheftArmed && settings.unplugAlarmEnabled) {
                    SecurityRepository.logEvent(
                        title = "Charger Disconnected!",
                        description = "Unauthorized power detachment detected while anti-theft shield is armed.",
                        severity = EventSeverity.ALERT,
                        type = EventType.CHARGER_DISCONNECTED
                    )
                    context?.let { SirenManager.startSiren(it) }
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        ensureAgentForegroundNotification()

        telemetryManager = TelemetryManager(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        val filter = IntentFilter(Intent.ACTION_POWER_DISCONNECTED)
        registerReceiver(powerReceiver, filter)

        // Telemetry background polling
        telemetryJob = serviceScope.launch {
            while (isActive && !backgroundTasksCleared) {
                val tel = telemetryManager.gatherTelemetry()
                SecurityRepository.updateTelemetry(tel)
                delay(15000)
            }
        }

        registerMotionSensor()

        val pairingPrefs = getSharedPreferences("agent_pairing", Context.MODE_PRIVATE)
        pairingPrefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "client_token") {
                attachRemoteCommandQueue()
            }
        }
        pairingPrefs.registerOnSharedPreferenceChangeListener(pairingPrefsListener)
        attachRemoteCommandQueue()
    }

    /**
     * Stops this Client app's nonessential polling and motion-sensor work.
     * The Firebase command listener remains alive so the owner can send a restart
     * or diagnostics command later. Android does not permit this app to kill
     * other apps' processes.
     */
    fun clearNonessentialBackgroundTasks(): String {
        backgroundTasksCleared = true
        telemetryJob?.cancel()
        telemetryJob = null
        sensorManager?.unregisterListener(this)
        return "Stopped this Client app's telemetry polling and motion-sensor monitoring. Other apps were not killed; Android does not allow this app to force-stop them."
    }

    private var attachedToken: String? = null
    private var pairingPrefsListener: android.content.SharedPreferences.OnSharedPreferenceChangeListener? = null

    @Synchronized
    private fun attachRemoteCommandQueue() {
        val prefs = getSharedPreferences("agent_pairing", Context.MODE_PRIVATE)
        val token = prefs.getString("client_token", null)?.takeIf { it.matches(Regex("^[A-HJ-NP-Z2-9]{8}$")) }
        if (token == null) {
            SecurityRepository.logEvent(
                "Remote queue waiting for pairing code",
                "Client token not set yet. Will attach when code is generated.",
                EventSeverity.INFO,
                EventType.REMOTE_COMMAND
            )
            return
        }
        if (attachedToken == token && remoteCommandListener != null) {
            return
        }

        remoteCommandRef?.let { ref -> remoteCommandListener?.let { ref.removeEventListener(it) } }
        attachedToken = token

        try {
            val db = FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
            val ref = db.reference.child("commands").child(token)
            ref.keepSynced(true)
            remoteCommandRef = ref

            syncSavedTargetApp(token)
            setupPresenceAndHeartbeat(token)

            val executedPrefs = getSharedPreferences("agent_executed_commands", Context.MODE_PRIVATE)

            val listener = object : ChildEventListener {
                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
                    handleRemoteCommand(snapshot, ref, token, executedPrefs)
                }
                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    handleRemoteCommand(snapshot, ref, token, executedPrefs)
                }
                override fun onChildRemoved(snapshot: DataSnapshot) {}
                override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}
                override fun onCancelled(error: DatabaseError) {
                    SecurityRepository.logEvent("Remote command listener unavailable", error.message,
                        EventSeverity.WARNING, EventType.REMOTE_COMMAND)
                }
            }
            remoteCommandListener = listener
            ref.addChildEventListener(listener)
            SecurityRepository.logEvent("Remote queue attached", "Listening for commands on token $token",
                EventSeverity.INFO, EventType.REMOTE_COMMAND)
        } catch (e: Exception) {
            SecurityRepository.logEvent("Remote command setup failed", e.localizedMessage ?: "Firebase unavailable",
                EventSeverity.WARNING, EventType.REMOTE_COMMAND)
        }
    }

    private var presenceRef: DatabaseReference? = null
    private var connectedListener: com.google.firebase.database.ValueEventListener? = null
    private var heartbeatJob: Job? = null

    private fun setupPresenceAndHeartbeat(token: String) {
        try {
            val db = FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
            val connectedRef = db.getReference(".info/connected")
            val clientPresenceRef = db.reference.child("clientPresence").child(token)
            presenceRef = clientPresenceRef

            connectedListener?.let { connectedRef.removeEventListener(it) }
            val listener = object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val connected = snapshot.getValue(Boolean::class.java) ?: false
                    if (connected) {
                        val tel = telemetryManager.gatherTelemetry()
                        clientPresenceRef.updateChildren(mapOf(
                            "isOnline" to true,
                            "status" to "ONLINE",
                            "lastSeen" to com.google.firebase.database.ServerValue.TIMESTAMP,
                            "batteryPercent" to tel.batteryPercent,
                            "deviceModel" to (android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL),
                            "token" to token
                        ))
                        clientPresenceRef.onDisconnect().updateChildren(mapOf(
                            "isOnline" to false,
                            "status" to "OFFLINE",
                            "lastSeen" to com.google.firebase.database.ServerValue.TIMESTAMP
                        ))
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            }
            connectedListener = listener
            connectedRef.addValueEventListener(listener)

            heartbeatJob?.cancel()
            heartbeatJob = serviceScope.launch {
                while (isActive) {
                    delay(20000L) // 20s heartbeat
                    try {
                        val tel = telemetryManager.gatherTelemetry()
                        clientPresenceRef.updateChildren(mapOf(
                            "isOnline" to true,
                            "status" to "ONLINE",
                            "lastSeen" to com.google.firebase.database.ServerValue.TIMESTAMP,
                            "batteryPercent" to tel.batteryPercent
                        ))
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {}
    }

    private fun handleRemoteCommand(
        snapshot: DataSnapshot,
        ref: DatabaseReference,
        token: String,
        executedPrefs: android.content.SharedPreferences
    ) {
        val id = snapshot.child("commandId").getValue(String::class.java)
            ?: snapshot.child("id").getValue(String::class.java) ?: snapshot.key ?: return
        val status = snapshot.child("status").getValue(String::class.java) ?: "PENDING"
        if (status != "PENDING") return

        if (executedPrefs.getBoolean("exec_$id", false)) {
            return
        }

        val typeName = snapshot.child("type").getValue(String::class.java) ?: run {
            ref.child(id).updateChildren(mapOf(
                "status" to "FAILED",
                "error" to "Command type missing",
                "resultSummary" to "Command type missing",
                "completedAt" to System.currentTimeMillis()
            ))
            return
        }

        val target = snapshot.child("targetClientId").getValue(String::class.java)
            ?: snapshot.child("targetDeviceId").getValue(String::class.java)
        if (!target.isNullOrBlank() && target != token) {
            ref.child(id).updateChildren(mapOf(
                "status" to "FAILED",
                "error" to "Target token mismatch",
                "resultSummary" to "Target token mismatch",
                "completedAt" to System.currentTimeMillis()
            ))
            return
        }

        val createdAt = snapshot.child("createdAt").getValue(Long::class.java)
            ?: snapshot.child("issuedAt").getValue(Long::class.java) ?: 0L
        if (createdAt > 0 && System.currentTimeMillis() - createdAt > 7200000L) {
            ref.child(id).updateChildren(mapOf(
                "status" to "TIMEOUT",
                "resultSummary" to "Command expired (>2 hours old)",
                "completedAt" to System.currentTimeMillis()
            ))
            return
        }

        val now = System.currentTimeMillis()
        ref.child(id).updateChildren(mapOf(
            "status" to "RECEIVED",
            "receivedAt" to now
        ))
        ref.child(id).updateChildren(mapOf(
            "status" to "RUNNING",
            "startedAt" to System.currentTimeMillis()
        ))

        executedPrefs.edit().putBoolean("exec_$id", true).apply()

        val type = try {
            com.example.model.CommandType.valueOf(typeName)
        } catch (_: Exception) {
            ref.child(id).updateChildren(mapOf(
                "status" to "FAILED",
                "error" to "Unsupported command type: $typeName",
                "resultSummary" to "Unsupported command type",
                "completedAt" to System.currentTimeMillis()
            ))
            return
        }

        val payload = snapshot.child("payload").getValue(String::class.java) ?: ""
        val command = com.example.model.AdminCommand(
            commandId = id,
            id = id,
            type = type,
            targetClientId = token,
            targetDeviceId = token,
            payload = payload,
            createdAt = if (createdAt > 0) createdAt else now,
            issuedAt = if (createdAt > 0) createdAt else now
        )

        val result = AgentCommandHandler(this@AgentService).executeCommandSync(command)

        ref.child(id).updateChildren(mapOf(
            "status" to result.status.name,
            "resultSummary" to result.summary,
            "error" to result.error,
            "completedAt" to System.currentTimeMillis()
        ))

        if (type == com.example.model.CommandType.REQUEST_DIAGNOSTICS) {
            publishTelemetry(token)
        }
    }

    private fun syncSavedTargetApp(token: String) {
        val clearPrefs = getSharedPreferences("background_clear_prefs", Context.MODE_PRIVATE)
        val pkg = clearPrefs.getString("selected_package", null)
        val label = clearPrefs.getString("selected_label", null)
        if (!pkg.isNullOrBlank() && !label.isNullOrBlank()) {
            try {
                FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                    .reference.child("clientSelectedApps").child(token)
                    .setValue(mapOf(
                        "packageName" to pkg,
                        "appName" to label,
                        "updatedAt" to System.currentTimeMillis()
                    ))
            } catch (_: Exception) {}
        }
    }

    private fun publishTelemetry(token: String) {
        try {
            val tel = telemetryManager.gatherTelemetry()
            val pm = getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
            val isBattOptIgnored = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && pm != null) {
                pm.isIgnoringBatteryOptimizations(packageName)
            } else true
            val dpcHelper = com.example.manager.DevicePolicyHelper(this)
            val isDpmAdmin = dpcHelper.isDeviceAdminActive()
            val isDpmOwner = dpcHelper.isDeviceOwner()

            FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                .reference.child("clientTelemetry").child(token).setValue(mapOf(
                    "manufacturer" to Build.MANUFACTURER,
                    "model" to Build.MODEL,
                    "osVersion" to ("Android " + Build.VERSION.RELEASE),
                    "apiLevel" to Build.VERSION.SDK_INT,
                    "batteryPercent" to tel.batteryPercent,
                    "isCharging" to tel.isCharging,
                    "ramUsagePercent" to tel.ramUsagePercent,
                    "networkType" to tel.networkType,
                    "ipAddress" to tel.ipAddress,
                    "isDeviceAdminActive" to isDpmAdmin,
                    "isDeviceOwnerActive" to isDpmOwner,
                    "isBatteryOptIgnored" to isBattOptIgnored,
                    "serviceRunning" to true,
                    "updatedAt" to System.currentTimeMillis()
                ))
        } catch (_: Exception) {}
    }

    private fun registerMotionSensor() {
        val settings = SecurityRepository.settings.value
        if (settings.motionAlarmEnabled && accelerometer != null) {
            sensorManager?.registerListener(
                this,
                accelerometer,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        lastAcceleration = currentAcceleration
        currentAcceleration = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
        val delta = currentAcceleration - lastAcceleration

        val settings = SecurityRepository.settings.value
        if (settings.antiTheftArmed && settings.motionAlarmEnabled && delta > shakeThreshold) {
            SecurityRepository.logEvent(
                title = "Motion Tamper Alert",
                description = "Sudden movement/displacement detected. Theft prevention triggered.",
                severity = EventSeverity.ALERT,
                type = EventType.MOTION_ALERT
            )
            SirenManager.startSiren(this)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureAgentForegroundNotification()
        attachRemoteCommandQueue()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        heartbeatJob?.cancel()
        try {
            presenceRef?.updateChildren(mapOf("isOnline" to false, "status" to "OFFLINE", "lastSeen" to com.google.firebase.database.ServerValue.TIMESTAMP))
        } catch (_: Exception) {}
        unregisterReceiver(powerReceiver)
        sensorManager?.unregisterListener(this)
        remoteCommandRef?.let { ref -> remoteCommandListener?.let { ref.removeEventListener(it) } }
        pairingPrefsListener?.let {
            getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(it)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Private Agent Security Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Foreground security monitoring and device anti-theft services"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Private Agent Active")
            .setContentText("Device protected with real-time anti-theft shield")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "private_agent_service_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private fun ensureAgentForegroundNotification() {
        val id = "personal_agent_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(id, "Personal Agent service", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(this, 1001, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0))
        val n = NotificationCompat.Builder(this, id)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Personal Agent is active")
            .setContentText("Background service is running. Tap to open the app.")
            .setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE).setPriority(NotificationCompat.PRIORITY_LOW).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1001, n)
    }

}
