package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import com.example.manager.SecurityRepository
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.service.AgentService

/**
 * Auto-starts Personal Agent background monitoring service upon device reboot / power on.
 * Supports standard boot, locked boot (Direct Boot), vendor quickboot, and package replacement.
 */
class AgentBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val validActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_USER_PRESENT,
            Intent.ACTION_REBOOT
        )

        if (!validActions.contains(action)) return

        // Acquire temporary wake lock to ensure foreground service start completes cleanly
        var wakeLock: PowerManager.WakeLock? = null
        try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            wakeLock = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PersonalAgent:BootAutoStart")
            wakeLock?.acquire(15000L) // 15 sec safeguard
        } catch (_: Exception) {}

        try {
            SecurityRepository.initialize(context)
            SecurityRepository.logEvent(
                title = "Auto-Start on Boot Triggered",
                description = "Device powered on / rebooted ($action). Starting background security agent service.",
                severity = EventSeverity.INFO,
                type = EventType.ADMIN_STATUS
            )

            val serviceIntent = Intent(context, AgentService::class.java).apply {
                putExtra("started_from_boot", true)
                putExtra("boot_action", action)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            SecurityRepository.logEvent(
                title = "Auto-Start Service Failed",
                description = "Could not start AgentService: ${e.message}",
                severity = EventSeverity.ALERT,
                type = EventType.ADMIN_STATUS
            )
        } finally {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock.release()
                }
            } catch (_: Exception) {}
        }
    }
}
