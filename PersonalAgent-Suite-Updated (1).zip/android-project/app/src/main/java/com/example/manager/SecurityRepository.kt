package com.example.manager

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AdminCommand
import com.example.model.AgentSettings
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.DeviceTelemetry
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.model.IntruderSnapshot
import com.example.model.ManagedDevice
import com.example.model.SecurityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object SecurityRepository {

    private val _telemetry = MutableStateFlow(DeviceTelemetry())
    val telemetry: StateFlow<DeviceTelemetry> = _telemetry.asStateFlow()

    private val _events = MutableStateFlow<List<SecurityEvent>>(emptyList())
    val events: StateFlow<List<SecurityEvent>> = _events.asStateFlow()

    private val _snapshots = MutableStateFlow<List<IntruderSnapshot>>(emptyList())
    val snapshots: StateFlow<List<IntruderSnapshot>> = _snapshots.asStateFlow()

    private val _settings = MutableStateFlow(AgentSettings())
    val settings: StateFlow<AgentSettings> = _settings.asStateFlow()

    private val _commands = MutableStateFlow<List<AdminCommand>>(emptyList())
    val commands: StateFlow<List<AdminCommand>> = _commands.asStateFlow()

    private val _managedDevices = MutableStateFlow<List<ManagedDevice>>(emptyList())
    val managedDevices: StateFlow<List<ManagedDevice>> = _managedDevices.asStateFlow()

    private val _isSirenActive = MutableStateFlow(false)
    val isSirenActive: StateFlow<Boolean> = _isSirenActive.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private var prefs: SharedPreferences? = null

    fun initialize(context: Context) {
        prefs = context.getSharedPreferences("private_agent_prefs", Context.MODE_PRIVATE)
        loadSettingsFromPrefs()
        seedInitialData()
    }

    private fun loadSettingsFromPrefs() {
        val p = prefs ?: return
        val armed = p.getBoolean("anti_theft_armed", true)
        val unplug = p.getBoolean("unplug_alarm_enabled", true)
        val motion = p.getBoolean("motion_alarm_enabled", false)
        val selfie = p.getBoolean("intruder_selfie_enabled", true)
        val maxAttempts = p.getInt("max_failed_attempts", 3)
        val lockMsg = p.getString(
            "custom_lock_message",
            "This device is protected by Private Agent. Please return to the owner."
        ) ?: "Protected by Private Agent."
        val phone = p.getString("owner_contact_phone", "+1 800-555-0199") ?: "+1 800-555-0199"
        val pin = p.getString("emergency_pin", "1234") ?: "1234"

        _settings.value = AgentSettings(
            antiTheftArmed = armed,
            unplugAlarmEnabled = unplug,
            motionAlarmEnabled = motion,
            intruderSelfieEnabled = selfie,
            maxFailedAttempts = maxAttempts,
            customLockMessage = lockMsg,
            ownerContactPhone = phone,
            emergencyPin = pin
        )
    }

    fun updateSettings(newSettings: AgentSettings) {
        _settings.value = newSettings
        prefs?.edit()?.apply {
            putBoolean("anti_theft_armed", newSettings.antiTheftArmed)
            putBoolean("unplug_alarm_enabled", newSettings.unplugAlarmEnabled)
            putBoolean("motion_alarm_enabled", newSettings.motionAlarmEnabled)
            putBoolean("intruder_selfie_enabled", newSettings.intruderSelfieEnabled)
            putInt("max_failed_attempts", newSettings.maxFailedAttempts)
            putString("custom_lock_message", newSettings.customLockMessage)
            putString("owner_contact_phone", newSettings.ownerContactPhone)
            putString("emergency_pin", newSettings.emergencyPin)
            putBoolean("camera_disabled_policy", newSettings.cameraDisabledByPolicy)
            apply()
        }
    }

    fun logEvent(
        title: String,
        description: String,
        severity: EventSeverity,
        type: EventType
    ) {
        val event = SecurityEvent(
            title = title,
            description = description,
            severity = severity,
            type = type
        )
        _events.update { current ->
            listOf(event) + current.take(99)
        }
    }

    fun addSnapshot(snapshot: IntruderSnapshot) {
        _snapshots.update { current ->
            listOf(snapshot) + current.take(49)
        }
    }

    fun updateTelemetry(telemetry: DeviceTelemetry) {
        _telemetry.value = telemetry
    }

    fun setSirenActive(active: Boolean) {
        _isSirenActive.value = active
    }

    fun setLocked(locked: Boolean) {
        _isLocked.value = locked
    }

    fun setPairedDevice(device: ManagedDevice) {
        _managedDevices.value = listOf(device)
    }

    fun parseCommandStatus(str: String?): CommandStatus = when (str?.uppercase()) {
        "PENDING" -> CommandStatus.PENDING
        "RECEIVED" -> CommandStatus.RECEIVED
        "RUNNING" -> CommandStatus.RUNNING
        "SUCCEEDED", "EXECUTED", "REQUESTED", "SUCCESS" -> CommandStatus.SUCCEEDED
        "TIMEOUT", "TIMED_OUT" -> CommandStatus.TIMEOUT
        "FAILED", "REJECTED_UNSUPPORTED", "REJECTED_WRONG_CLIENT" -> CommandStatus.FAILED
        else -> CommandStatus.PENDING
    }

    fun sendRemoteCommand(
        context: Context,
        targetToken: String,
        type: CommandType,
        payload: String = "",
        onResult: ((CommandStatus, String) -> Unit)? = null
    ): AdminCommand {
        val commandId = java.util.UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        val cmd = AdminCommand(
            commandId = commandId,
            id = commandId,
            type = type,
            targetClientId = targetToken,
            targetDeviceId = targetToken,
            payload = payload,
            createdAt = now,
            issuedAt = now,
            status = CommandStatus.PENDING,
            resultSummary = "Sending to Firebase..."
        )
        addCommand(cmd)

        if (!targetToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
            updateCommandStatus(commandId, CommandStatus.FAILED, "No paired Client. Enter an 8-character code first.")
            onResult?.invoke(CommandStatus.FAILED, "No paired Client. Enter an 8-character code first.")
            return cmd
        }

        try {
            val ref = com.google.firebase.database.FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                .reference.child("commands").child(targetToken).child(commandId)

            val commandData = mapOf(
                "commandId" to commandId,
                "id" to commandId,
                "targetClientId" to targetToken,
                "targetDeviceId" to targetToken,
                "type" to type.name,
                "payload" to payload,
                "createdAt" to now,
                "issuedAt" to now,
                "status" to "PENDING",
                "resultSummary" to "",
                "error" to ""
            )

            val valueListener = object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    val statusStr = snapshot.child("status").getValue(String::class.java) ?: "PENDING"
                    val status = parseCommandStatus(statusStr)
                    val summary = snapshot.child("resultSummary").getValue(String::class.java)
                        ?: snapshot.child("error").getValue(String::class.java) ?: ""
                    updateCommandStatus(commandId, status, summary)
                    onResult?.invoke(status, summary)
                    if (status == CommandStatus.SUCCEEDED || status == CommandStatus.FAILED || status == CommandStatus.TIMEOUT) {
                        try { ref.removeEventListener(this) } catch (_: Exception) {}
                    }
                }
                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                    updateCommandStatus(commandId, CommandStatus.FAILED, "Firebase error: ${error.message}")
                    onResult?.invoke(CommandStatus.FAILED, error.message)
                }
            }
            ref.addValueEventListener(valueListener)

            // 25 second timeout safeguard
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                val current = _commands.value.find { it.commandId == commandId || it.id == commandId }
                if (current != null && current.status == CommandStatus.PENDING) {
                    try { ref.removeEventListener(valueListener) } catch (_: Exception) {}
                    updateCommandStatus(
                        commandId,
                        CommandStatus.TIMEOUT,
                        "Command timed out waiting for Client acknowledgement. Ensure Client is online and background service is active."
                    )
                    onResult?.invoke(CommandStatus.TIMEOUT, "Command timed out after 25s.")
                }
            }, 25000L)

            ref.setValue(commandData)
                .addOnSuccessListener {
                    logEvent("Remote command queued", "Dispatched ${type.name} to Client $targetToken", EventSeverity.INFO, EventType.REMOTE_COMMAND)
                }
                .addOnFailureListener { error ->
                    try { ref.removeEventListener(valueListener) } catch (_: Exception) {}
                    updateCommandStatus(commandId, CommandStatus.FAILED, "Send failed: ${error.message}")
                    onResult?.invoke(CommandStatus.FAILED, "Firebase write rejected: ${error.message}")
                }
        } catch (e: Exception) {
            updateCommandStatus(commandId, CommandStatus.FAILED, "Firebase unavailable: ${e.message}")
            onResult?.invoke(CommandStatus.FAILED, e.message ?: "Firebase unavailable")
        }

        return cmd
    }

    private var activeHistoryToken: String? = null
    fun startCommandHistoryListener(token: String) {
        if (!token.matches(Regex("^[A-HJ-NP-Z2-9]{8}$")) || activeHistoryToken == token) return
        activeHistoryToken = token
        try {
            val ref = com.google.firebase.database.FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                .reference.child("commands").child(token)
            ref.addChildEventListener(object : com.google.firebase.database.ChildEventListener {
                override fun onChildAdded(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {
                    updateFromSnapshot(snapshot)
                }
                override fun onChildChanged(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {
                    updateFromSnapshot(snapshot)
                }
                override fun onChildRemoved(snapshot: com.google.firebase.database.DataSnapshot) {}
                override fun onChildMoved(snapshot: com.google.firebase.database.DataSnapshot, previousChildName: String?) {}
                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {}
            })
        } catch (_: Exception) {}
    }

    private fun updateFromSnapshot(snapshot: com.google.firebase.database.DataSnapshot) {
        val id = snapshot.child("commandId").getValue(String::class.java)
            ?: snapshot.child("id").getValue(String::class.java) ?: snapshot.key ?: return
        val typeStr = snapshot.child("type").getValue(String::class.java) ?: return
        val type = try { CommandType.valueOf(typeStr) } catch (_: Exception) { return }
        val target = snapshot.child("targetClientId").getValue(String::class.java)
            ?: snapshot.child("targetDeviceId").getValue(String::class.java) ?: ""
        val statusStr = snapshot.child("status").getValue(String::class.java) ?: "PENDING"
        val status = parseCommandStatus(statusStr)
        val result = snapshot.child("resultSummary").getValue(String::class.java)
            ?: snapshot.child("error").getValue(String::class.java) ?: ""
        val createdAt = snapshot.child("createdAt").getValue(Long::class.java)
            ?: snapshot.child("issuedAt").getValue(Long::class.java) ?: System.currentTimeMillis()
        val payload = snapshot.child("payload").getValue(String::class.java) ?: ""

        _commands.update { current ->
            val existing = current.find { it.commandId == id || it.id == id }
            if (existing != null) {
                current.map {
                    if (it.commandId == id || it.id == id) {
                        it.copy(status = status, resultSummary = result)
                    } else it
                }
            } else {
                listOf(AdminCommand(
                    commandId = id,
                    id = id,
                    type = type,
                    targetClientId = target,
                    targetDeviceId = target,
                    payload = payload,
                    createdAt = createdAt,
                    issuedAt = createdAt,
                    status = status,
                    resultSummary = result
                )) + current.take(49)
            }
        }
    }

    fun addCommand(command: AdminCommand) {
        // Remote queue is addressed by the approved pairing token. Unsupported
        // remote command types are rejected by the Client service.
        val targetToken = if (command.targetClientId.isNotBlank()) command.targetClientId else command.targetDeviceId
        if (targetToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
            try {
                com.google.firebase.database.FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference
                    .child("commands").child(targetToken).child(command.commandId)
                    .setValue(mapOf(
                        "commandId" to command.commandId,
                        "id" to command.commandId,
                        "type" to command.type.name,
                        "targetClientId" to targetToken,
                        "targetDeviceId" to targetToken,
                        "payload" to command.payload,
                        "createdAt" to command.createdAt,
                        "issuedAt" to command.createdAt,
                        "status" to "PENDING",
                        "resultSummary" to command.resultSummary
                    ))
                    .addOnSuccessListener {
                        logEvent(
                            "Remote command queued",
                            "Command " + command.type.name + " queued for paired Client token " + targetToken.take(8),
                            EventSeverity.INFO,
                            EventType.REMOTE_COMMAND
                        )
                    }
                    .addOnFailureListener { error ->
                        logEvent(
                            "Remote command send failed",
                            error.message ?: "Firebase rejected command write. Check authenticated session and Realtime Database rules.",
                            EventSeverity.WARNING,
                            EventType.REMOTE_COMMAND
                        )
                    }
            } catch (error: Exception) {
                logEvent(
                    "Remote command send failed",
                    error.message ?: "Firebase database unavailable",
                    EventSeverity.WARNING,
                    EventType.REMOTE_COMMAND
                )
            }
        }
        _commands.update { current ->
            listOf(command) + current.take(49)
        }
    }

    fun updateCommandStatus(commandId: String, status: CommandStatus, resultSummary: String) {
        _commands.update { current ->
            current.map { cmd ->
                if (cmd.commandId == commandId || cmd.id == commandId) {
                    cmd.copy(status = status, resultSummary = resultSummary)
                } else {
                    cmd
                }
            }
        }
    }

    private fun seedInitialData() {
        if (_events.value.isEmpty()) {
            val now = System.currentTimeMillis()
            _events.value = listOf(
                SecurityEvent(
                    timestamp = now - 3600000 * 2,
                    title = "Agent Service Initialized",
                    description = "Private Agent security subsystem booted and actively monitoring hardware telemetry.",
                    severity = EventSeverity.INFO,
                    type = EventType.ADMIN_STATUS
                ),
                SecurityEvent(
                    timestamp = now - 3600000,
                    title = "Integrity Check Passed",
                    description = "Full system audit executed: Encryption verified, no unauthorized root binary found.",
                    severity = EventSeverity.INFO,
                    type = EventType.ADMIN_STATUS
                ),
                SecurityEvent(
                    timestamp = now - 1800000,
                    title = "Anti-Theft Armed",
                    description = "Intruder detection, unplug alert, and motion shield armed in background.",
                    severity = EventSeverity.INFO,
                    type = EventType.POLICY_CHANGE
                )
            )
        }

        // Remote devices must come from a real, consent-based pairing/backend.
        _managedDevices.value = emptyList()
    }
}
