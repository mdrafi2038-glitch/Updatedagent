package com.example.ui.screens

import com.google.firebase.database.FirebaseDatabase

import com.google.firebase.database.ValueEventListener

import com.google.firebase.database.DatabaseError

import com.google.firebase.database.DataSnapshot

import com.example.ui.components.PairingPanel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.manager.AgentCommandHandler
import com.example.manager.SecurityRepository
import com.example.model.AdminCommand
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.ManagedDevice
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariantDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarningAmber

@Composable
fun AdminControllerScreen() {
    val context = LocalContext.current
    val devices by SecurityRepository.managedDevices.collectAsState()
    val commands by SecurityRepository.commands.collectAsState()
    val isSirenActive by SecurityRepository.isSirenActive.collectAsState()

    var selectedDeviceId by remember { mutableStateOf("") }
    LaunchedEffect(devices) {
        if (selectedDeviceId.isBlank() && devices.isNotEmpty()) {
            selectedDeviceId = devices.first().deviceId
        }
    }
    var showWipeConfirmDialog by remember { mutableStateOf(false) }
    var showPowerOffConfirmDialog by remember { mutableStateOf(false) }

    val selectedDevice = devices.find { it.deviceId == selectedDeviceId } ?: devices.firstOrNull()

    var clientIsOnline by remember { mutableStateOf(false) }
    var clientLastSeen by remember { mutableStateOf(0L) }
    var clientStatusText by remember { mutableStateOf("Awaiting Client Connection") }
    var clientBattery by remember { mutableStateOf<Int?>(null) }

    val adminToken = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE)
        .getString("admin_token", "") ?: ""

    LaunchedEffect(adminToken) {
        if (adminToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
            FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                .reference.child("clientPresence").child(adminToken)
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val isOnline = snapshot.child("isOnline").getValue(Boolean::class.java) ?: false
                        val lastSeen = snapshot.child("lastSeen").getValue(Long::class.java) ?: 0L
                        val status = snapshot.child("status").getValue(String::class.java) ?: if (isOnline) "ONLINE" else "OFFLINE"
                        val batt = snapshot.child("batteryPercent").getValue(Int::class.java)
                        clientIsOnline = isOnline
                        clientLastSeen = lastSeen
                        clientStatusText = status
                        clientBattery = batt
                    }
                    override fun onCancelled(error: DatabaseError) {
                        clientStatusText = "Presence check failed"
                    }
                })
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyDark)
            .testTag("admin_controller_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Real-Time Online / Offline Status Badge Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (clientIsOnline) Color(0xFF06231A) else Color(0xFF1E1214)
                ),
                border = BorderStroke(
                    1.5.dp,
                    if (clientIsOnline) CyberSuccessGreen else CyberAlertCrimson.copy(alpha = 0.7f)
                )
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(
                                        if (clientIsOnline) CyberSuccessGreen else CyberAlertCrimson,
                                        CircleShape
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (clientIsOnline) "CLIENT PHONE ONLINE" else "CLIENT PHONE OFFLINE",
                                color = if (clientIsOnline) CyberSuccessGreen else CyberAlertCrimson,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(
                                    if (clientIsOnline) CyberSuccessGreen.copy(alpha = 0.2f) else CyberAlertCrimson.copy(alpha = 0.2f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (clientIsOnline) "ACTIVE" else "DISCONNECTED",
                                color = if (clientIsOnline) CyberSuccessGreen else CyberAlertCrimson,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = if (clientIsOnline) {
                            "Client device is currently connected to Firebase Realtime Database. Background security service is running and ready to receive commands."
                        } else {
                            "Client phone is offline or device is powered off. Commands sent will queue until device turns back on and auto-starts."
                        },
                        color = CyberTextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    if (adminToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Token: $adminToken" + (if (clientBattery != null) " • Battery: $clientBattery%" else ""),
                                color = CyberCyanPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )

                            if (clientLastSeen > 0L) {
                                val secondsAgo = (System.currentTimeMillis() - clientLastSeen) / 1000
                                val timeText = if (secondsAgo < 60) "${secondsAgo}s ago" else "${secondsAgo / 60}m ago"
                                Text(
                                    text = "Last seen: $timeText",
                                    color = CyberTextMuted,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            var clearCommandStatus by remember { mutableStateOf("Choose a paired Client, then send a request.") }
            var clearCommandState by remember { mutableStateOf(CommandStatus.PENDING) }
            val clearToken = adminToken

            androidx.compose.runtime.LaunchedEffect(clearToken) {
                if (clearToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
                    SecurityRepository.startCommandHistoryListener(clearToken)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(12.dp)) {
                Text("CLEAR BACKGROUND PROCESSES", color = CyberCyanPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                var selectedClientApp by remember { mutableStateOf("Loading Client selection…") }
                if (clearToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
                    androidx.compose.runtime.LaunchedEffect(clearToken) {
                        FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/")
                            .reference.child("clientSelectedApps").child(clearToken)
                            .addValueEventListener(object : ValueEventListener {
                                override fun onDataChange(snapshot: DataSnapshot) {
                                    val name = snapshot.child("appName").getValue(String::class.java)
                                    val pkg = snapshot.child("packageName").getValue(String::class.java)
                                    selectedClientApp = if (!name.isNullOrBlank()) name + (if (!pkg.isNullOrBlank()) " ($pkg)" else "") else "No app selected on Client"
                                }
                                override fun onCancelled(error: DatabaseError) { selectedClientApp = "Could not load selection: " + error.message }
                            })
                    }
                } else { selectedClientApp = "Pair a Client to see its selected app" }

                Text("Target Application on Client: " + selectedClientApp, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text("Sends command to Client to clear cached background processes via ActivityManager.killBackgroundProcesses. Nonessential Client tasks are paused.", color = CyberTextSecondary, fontSize = 11.sp)

                Button(
                    onClick = {
                        if (!clearToken.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
                            clearCommandStatus = "Pair a Client first; no valid 8-character Client code is saved."
                            clearCommandState = CommandStatus.FAILED
                        } else {
                            clearCommandStatus = "Sending command to Firebase…"
                            clearCommandState = CommandStatus.PENDING
                            SecurityRepository.sendRemoteCommand(
                                context = context,
                                targetToken = clearToken,
                                type = CommandType.CLEAR_BACKGROUND_PROCESSES
                            ) { status, summary ->
                                clearCommandState = status
                                clearCommandStatus = "Status: ${status.name}" + (if (summary.isNotBlank()) "\n$summary" else "")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary)
                ) {
                    Text("Clear Background on Client", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }

                val statusColor = when (clearCommandState) {
                    CommandStatus.PENDING -> CyberWarningAmber
                    CommandStatus.RECEIVED -> Color(0xFF38BDF8)
                    CommandStatus.RUNNING -> Color(0xFFA855F7)
                    CommandStatus.SUCCEEDED, CommandStatus.EXECUTED -> CyberSuccessGreen
                    CommandStatus.FAILED -> CyberAlertCrimson
                    CommandStatus.TIMEOUT -> Color(0xFFFF6B00)
                }
                Text(clearCommandStatus, color = statusColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }

        item { PairingPanel(isAdmin = true) }
        // Header
        item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = CyberCyanPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ADMIN COMMAND CONSOLE",
                        color = CyberCyanPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Fleet & Remote Device Controller",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "Dispatch security policies and remote emergency triggers to agent endpoints.",
                    color = CyberTextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Managed Devices Selector Carousel
        item {
            Text(
                text = "TARGET ENDPOINT",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (devices.isEmpty()) {
                    Text(
                        text = "No client paired yet. Generate a code here, then enter it on the Client phone and approve the request there.",
                        color = CyberWarningAmber,
                        fontSize = 13.sp
                    )
                } else {
                    devices.forEach { dev ->
                        DeviceSelectorCard(
                            device = dev,
                            isSelected = dev.deviceId == selectedDeviceId,
                            onSelect = { selectedDeviceId = dev.deviceId }
                        )
                    }
                }
            }
        }

        // Remote Actions Grid
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("remote_actions_section")
            ) {
                Text(
                    text = "REMOTE ACTIONS",
                    color = CyberCyanPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Dispatch Security Controls",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Trigger simulated enterprise commands to manage and secure target endpoint.",
                    color = CyberTextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Lock Device Command
                    RemoteCommandBtn(
                        title = "Lock Device",
                        desc = "Force lockdown overlay",
                        icon = Icons.Default.Lock,
                        accentColor = CyberShieldSecondary,
                        modifier = Modifier.weight(1f).testTag("remote_action_lock"),
                        onClick = {
                            val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                            SecurityRepository.sendRemoteCommand(context, token, CommandType.LOCK_DEVICE) { status, summary ->
                                Toast.makeText(context, "Lockdown: ${status.name}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )

                    // Power Off Device Command (Featured at top!)
                    RemoteCommandBtn(
                        title = "Lock + Power Options",
                        desc = "Show Client restriction screen",
                        icon = Icons.Default.PowerSettingsNew,
                        accentColor = CyberAlertCrimson,
                        modifier = Modifier.weight(1f).testTag("remote_action_power_off_btn"),
                        onClick = {
                            showPowerOffConfirmDialog = true
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Locate Device Command
                    RemoteCommandBtn(
                        title = "Locate Device",
                        desc = "Query GPS coordinates",
                        icon = Icons.Default.MyLocation,
                        accentColor = CyberCyanPrimary,
                        modifier = Modifier.weight(1f).testTag("remote_action_locate"),
                        onClick = {
                            val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                            SecurityRepository.sendRemoteCommand(context, token, CommandType.LOCATE_DEVICE) { status, summary ->
                                Toast.makeText(context, "Locate: ${status.name}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )

                    // Siren Alarm Command
                    RemoteCommandBtn(
                        title = if (isSirenActive) "Silence Siren" else "Trigger Siren",
                        desc = if (isSirenActive) "Stop emergency tone" else "Audible 100dB strobe",
                        icon = if (isSirenActive) Icons.Default.NotificationsOff else Icons.Default.NotificationsActive,
                        accentColor = if (isSirenActive) CyberAlertCrimson else CyberCyanPrimary,
                        modifier = Modifier.weight(1f).testTag("cmd_siren"),
                        onClick = {
                            val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                            val type = if (isSirenActive) CommandType.STOP_SIREN else CommandType.TRIGGER_SIREN
                            SecurityRepository.sendRemoteCommand(context, token, type) { status, summary ->
                                if (status == CommandStatus.SUCCEEDED || status == CommandStatus.EXECUTED) {
                                    SecurityRepository.setSirenActive(type == CommandType.TRIGGER_SIREN)
                                }
                                Toast.makeText(context, "${type.name}: ${status.name}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Capture Photo Command
                    RemoteCommandBtn(
                        title = "Snapshot Photo",
                        desc = "Capture intruder selfie",
                        icon = Icons.Default.CameraAlt,
                        accentColor = CyberWarningAmber,
                        modifier = Modifier.weight(1f).testTag("cmd_photo"),
                        onClick = {
                            Toast.makeText(context, "Remote photo capture is not implemented in the Trial build.", Toast.LENGTH_LONG).show()
                        }
                    )

                    // Live Diagnostics
                    RemoteCommandBtn(
                        title = "Live Diagnostics",
                        desc = "Fetch telemetry status",
                        icon = Icons.Default.Sensors,
                        accentColor = CyberSuccessGreen,
                        modifier = Modifier.weight(1f).testTag("cmd_diagnostics"),
                        onClick = {
                            val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                            SecurityRepository.sendRemoteCommand(context, token, CommandType.REQUEST_DIAGNOSTICS) { status, summary ->
                                Toast.makeText(context, "Diagnostics: ${status.name}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Camera Policy Toggle
                    RemoteCommandBtn(
                        title = "Camera Policy",
                        desc = "Toggle hardware sensor",
                        icon = Icons.Default.VpnKey,
                        accentColor = Color(0xFFA855F7),
                        modifier = Modifier.weight(1f).testTag("cmd_policy"),
                        onClick = {
                            val cmd = AdminCommand(type = CommandType.TOGGLE_CAMERA_POLICY, targetDeviceId = (context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""))
                            SecurityRepository.addCommand(cmd)
                            Toast.makeText(context, "Policy Command Sent", Toast.LENGTH_SHORT).show()
                        }
                    )

                    // Clear Background Apps Command
                    RemoteCommandBtn(
                        title = "Clear Background",
                        desc = "Kill Client BG apps",
                        icon = Icons.Default.PhoneAndroid,
                        accentColor = CyberCyanPrimary,
                        modifier = Modifier.weight(1f).testTag("cmd_clear_background"),
                        onClick = {
                            val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                            SecurityRepository.sendRemoteCommand(context, token, CommandType.CLEAR_BACKGROUND_PROCESSES) { status, summary ->
                                Toast.makeText(context, "Clear BG Apps: ${status.name}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Wipe Data Button
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("remote_action_wipe")
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showWipeConfirmDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberAlertCrimson.copy(alpha = 0.1f)),
                    border = BorderStroke(1.dp, CyberAlertCrimson.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(CyberAlertCrimson.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, tint = CyberAlertCrimson)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Wipe Data", color = CyberAlertCrimson, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Simulate emergency factory reset to prevent data theft", color = CyberTextSecondary, fontSize = 11.sp)
                        }
                        Text("DANGER", color = CyberAlertCrimson, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Power Off Device Button
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("remote_action_power_off")
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { showPowerOffConfirmDialog = true },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF261014)),
                    border = BorderStroke(1.dp, CyberAlertCrimson.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(CyberAlertCrimson.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = CyberAlertCrimson)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Power Off Device", color = CyberAlertCrimson, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Remotely shut down client phone and stop hardware", color = CyberTextSecondary, fontSize = 11.sp)
                        }
                        Text("POWER OFF", color = CyberAlertCrimson, fontSize = 10.sp, fontWeight = FontWeight.Black)
                    }
                }
            }
        }

        // Live Command Execution Terminal Log
        item {
            Text(
                text = "COMMAND AUDIT TRAIL",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            if (commands.isEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, CyberBorderDark)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No remote commands issued yet. Use controls above.", color = CyberTextMuted, fontSize = 12.sp)
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    commands.take(6).forEach { cmd ->
                        CommandTerminalCard(cmd)
                    }
                }
            }
        }
    }

    if (showWipeConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showWipeConfirmDialog = false },
            title = {
                Text("Confirm Emergency Wipe", color = CyberAlertCrimson, fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "Are you sure you want to trigger a remote factory wipe on ${selectedDevice?.deviceName}? This will erase all user data permanently.",
                    color = CyberTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showWipeConfirmDialog = false
                        val cmd = AdminCommand(type = CommandType.WIPE_DEVICE, targetDeviceId = (context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""))
                        SecurityRepository.addCommand(cmd)
                        Toast.makeText(context, "Emergency Wipe Command Executed", Toast.LENGTH_LONG).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAlertCrimson)
                ) {
                    Text("Execute Wipe", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWipeConfirmDialog = false }) {
                    Text("Cancel", color = CyberTextSecondary)
                }
            },
            containerColor = CyberSurfaceDark
        )
    }

    if (showPowerOffConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showPowerOffConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = CyberAlertCrimson)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Show Client Power Options", color = CyberAlertCrimson, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Text(
                    "Are you sure you want to remotely power off ${selectedDevice?.deviceName}? This will open the Client restriction screen. Actual restart or shutdown depends on Android permissions.",
                    color = CyberTextSecondary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPowerOffConfirmDialog = false
                        val token = context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE).getString("admin_token", "") ?: ""
                        SecurityRepository.sendRemoteCommand(context, token, CommandType.LOCK_DEVICE) { status, summary ->
                            Toast.makeText(context, "Lock + Power: ${status.name}", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAlertCrimson)
                ) {
                    Text("Power Off Device", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPowerOffConfirmDialog = false }) {
                    Text("Cancel", color = CyberTextSecondary)
                }
            },
            containerColor = CyberSurfaceDark
        )
    }
}

@Composable
fun DeviceSelectorCard(
    device: ManagedDevice,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onSelect() }
            .testTag("device_card_${device.deviceId}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) CyberSurfaceDark else Color(0xFF0F172A)
        ),
        border = BorderStroke(
            if (isSelected) 1.5.dp else 1.dp,
            if (isSelected) CyberCyanPrimary else CyberBorderDark
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(
                        if (isSelected) CyberCyanPrimary.copy(alpha = 0.2f) else CyberSurfaceVariantDark,
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PhoneAndroid,
                    contentDescription = null,
                    tint = if (isSelected) CyberCyanPrimary else CyberTextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = device.deviceName,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .background(
                                if (device.isOnline) CyberSuccessGreen else CyberTextMuted,
                                CircleShape
                            )
                    )
                }
                Text(
                    text = "${device.model} • ${device.osVersion} • Battery: ${device.batteryPercent}%",
                    color = CyberTextSecondary,
                    fontSize = 11.sp
                )
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .background(CyberCyanPrimary, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("SELECTED", color = Color(0xFF00363D), fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
fun RemoteCommandBtn(
    title: String,
    desc: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
        border = BorderStroke(1.dp, CyberBorderDark)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = desc, color = CyberTextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
fun CommandTerminalCard(cmd: AdminCommand) {
    val statusColor = when (cmd.status) {
        CommandStatus.PENDING -> CyberWarningAmber
        CommandStatus.RECEIVED -> Color(0xFF38BDF8)
        CommandStatus.RUNNING -> Color(0xFFA855F7)
        CommandStatus.SUCCEEDED, CommandStatus.EXECUTED -> CyberSuccessGreen
        CommandStatus.FAILED -> CyberAlertCrimson
        CommandStatus.TIMEOUT -> Color(0xFFFF6B00)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1222)),
        border = BorderStroke(1.dp, CyberBorderDark)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "> ${cmd.type.name}",
                    color = CyberCyanPrimary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = cmd.status.name,
                    color = statusColor,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
            if (cmd.resultSummary.isNotEmpty()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = cmd.resultSummary,
                    color = CyberTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
