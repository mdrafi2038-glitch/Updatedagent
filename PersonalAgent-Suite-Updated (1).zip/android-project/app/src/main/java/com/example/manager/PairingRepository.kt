package com.example.manager

import android.content.Context
import android.os.Build
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import java.util.UUID

object PairingRepository {
    private const val ROOT = "pairRequests"
    private const val EXPIRY = 600000L

    fun signIn(done: (String?, String?) -> Unit) {
        val completed = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finish(uid: String?, error: String?) {
            if (completed.compareAndSet(false, true)) done(uid, error)
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            finish(null, "Firebase sign-in timed out. Check internet and Firebase Authentication.")
        }, 15000L)
        try {
            val auth = FirebaseAuth.getInstance()
            val currentUser = auth.currentUser
            if (currentUser != null) { finish(currentUser.uid, null); return }
            auth.signInAnonymously()
                .addOnSuccessListener { finish(it.user?.uid, null) }
                .addOnFailureListener { finish(null, it.message ?: "Firebase sign-in failed") }
        } catch (e: Exception) {
            finish(null, "Firebase configuration missing or unavailable: " + (e.message ?: "check google-services.json and Authentication providers."))
        }
    }

    fun create(context: Context, done: (String?, String?) -> Unit) = signIn { uid, err ->
        if (uid == null) { done(null, err); return@signIn }
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val secureRandom = java.security.SecureRandom()
        val token = (1..8).map { alphabet[secureRandom.nextInt(alphabet.length)] }.joinToString("")
        val data = mapOf(
            "clientUid" to uid,
            "deviceName" to (Build.MANUFACTURER + " " + Build.MODEL).trim(),
            "model" to Build.MODEL,
            "osVersion" to ("Android " + Build.VERSION.RELEASE),
            "createdAt" to System.currentTimeMillis(),
            "approved" to false
        )
        try {
            FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token).setValue(data)
                .addOnSuccessListener {
                    context.getSharedPreferences("agent_pairing", Context.MODE_PRIVATE)
                        .edit().putString("client_token", token).apply()
                    done(token, null)
                }.addOnFailureListener { done(null, it.message ?: "Database write failed; check Firebase rules") }
        } catch (e: Exception) { done(null, e.message ?: "Firebase database unavailable") }
    }

    fun revoke(context: Context, token: String) {
        if (token.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
            try {
                FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token).child("revoked")
                    .setValue(true)
            } catch (_: Exception) { }
        }
    }

    fun request(raw: String, done: (String?, String?) -> Unit) {
        val completed = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finish(token: String?, error: String?) {
            if (completed.compareAndSet(false, true)) done(token, error)
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            finish(null, "Pairing request timed out. Check database rules, internet, and Firebase project URL.")
        }, 20000L)
        val token = raw.trim().uppercase()
        if (!token.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) {
            finish(null, "Enter the 8-character code from Client."); return
        }
        signIn { uid, err ->
            if (uid == null) { finish(null, err); return@signIn }
            try {
                val ref = FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token)
                ref.get().addOnSuccessListener { snap ->
                    val created = snap.child("createdAt").getValue(Long::class.java) ?: 0L
                    if (!snap.exists() || snap.child("revoked").getValue(Boolean::class.java) == true ||
                        (snap.child("approved").getValue(Boolean::class.java) != true &&
                         System.currentTimeMillis() - created > EXPIRY)) {
                        finish(null, "Code invalid or expired. Generate a new one on Client."); return@addOnSuccessListener
                    }
                    if (snap.child("approved").getValue(Boolean::class.java) == true) {
                        finish(null, "This code has already been used."); return@addOnSuccessListener
                    }
                    ref.child("adminUid").setValue(uid).addOnSuccessListener {
                        ref.child("adminRequestedAt").setValue(System.currentTimeMillis())
                            .addOnSuccessListener { finish(token, null) }
                            .addOnFailureListener { finish(null, "Could not write adminRequestedAt: " + (it.message ?: "permission denied")) }
                    }.addOnFailureListener { finish(null, "Could not write adminUid: " + (it.message ?: "permission denied")) }
                }.addOnFailureListener { finish(null, "Database read failed: " + (it.message ?: "check Firebase rules")) }
            } catch (e: Exception) { finish(null, e.message ?: "Firebase database unavailable") }
        }
    }

    fun approve(token: String, done: (String?) -> Unit) = signIn { uid, err ->
        if (uid == null) { done(err); return@signIn }
        try {
            FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token).updateChildren(
                mapOf("approved" to true, "pairedClientUid" to uid, "pairedAt" to System.currentTimeMillis())
            ).addOnSuccessListener { done(null) }
                .addOnFailureListener { done(it.message ?: "Approval failed") }
        } catch (e: Exception) { done(e.message ?: "Firebase database unavailable") }
    }

    fun listen(token: String, changed: (DataSnapshot) -> Unit, failed: (String) -> Unit): ValueEventListener? {
        if (!token.matches(Regex("^[A-HJ-NP-Z2-9]{8}$"))) return null
        return try {
            val ref = FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token)
            val listener = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) = changed(snapshot)
                override fun onCancelled(error: DatabaseError) = failed(error.message)
            }
            ref.addValueEventListener(listener)
            listener
        } catch (e: Exception) { failed(e.message ?: "Firebase unavailable"); null }
    }

    fun remove(token: String, listener: ValueEventListener?) {
        if (listener != null) try {
            FirebaseDatabase.getInstance("https://private-agent-98752-default-rtdb.firebaseio.com/").reference.child(ROOT).child(token).removeEventListener(listener)
        } catch (_: Exception) { }
    }

    fun authenticateAccount(email: String, password: String, create: Boolean, done: (String?, String?) -> Unit) {
        val e = email.trim()
        if (e.isBlank() || password.length < 6) {
            done(null, "Enter a valid email and password (at least 6 characters).")
            return
        }
        val completed = java.util.concurrent.atomic.AtomicBoolean(false)
        val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
        fun finish(uid: String?, message: String?) {
            if (completed.compareAndSet(false, true)) {
                mainHandler.removeCallbacksAndMessages(null)
                mainHandler.post { done(uid, message) }
            }
        }
        // Never leave the UI stuck on "Signing in…" if Firebase does not complete its Task.
        mainHandler.postDelayed({
            finish(null, "Sign-in timed out after 20 seconds. Check internet, Firebase Authentication > Email/Password, and the app's google-services.json.")
        }, 20000L)
        try {
            val auth = FirebaseAuth.getInstance()
            val task = if (create) auth.createUserWithEmailAndPassword(e, password)
                       else auth.signInWithEmailAndPassword(e, password)
            task.addOnSuccessListener { finish(it.user?.uid, null) }
                .addOnFailureListener { finish(null, it.message ?: "Firebase account sign-in failed") }
        } catch (e: Exception) {
            finish(null, e.message ?: "Firebase Authentication unavailable. Check Firebase configuration.")
        }
    }

}
