package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.content.Context
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PermDeviceInformation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.manager.PermissionHelper
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.manager.TelemetryManager
import com.example.service.AgentService
import com.example.ui.components.MdmPermissionDialog
import com.example.ui.screens.AgentDashboardScreen
import com.example.ui.screens.AntiTheftScreen
import com.example.ui.screens.AuditLogScreen
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.IntruderVaultScreen
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarningAmber
import com.example.ui.theme.MyApplicationTheme

enum class MainNavTab(val title: String, val icon: ImageVector) {
    DASHBOARD("Agent", Icons.Default.Shield),
    ANTI_THEFT("Shield", Icons.Default.Lock),
    DIAGNOSTICS("Diagnostics", Icons.Default.PermDeviceInformation),
    VAULT("Vault", Icons.Default.CameraAlt),
    LOGS("Audit", Icons.Default.History)
}

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Telemetry update after permission check
        val telMgr = TelemetryManager(this)
        SecurityRepository.updateTelemetry(telMgr.gatherTelemetry())
        telMgr.requestLocationUpdate()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // AUTO_START_CLIENT_AGENT_SERVICE
        if (packageName == "com.personalagent.client") {
            val agentPrefs = getSharedPreferences("agent_service_settings", Context.MODE_PRIVATE)
            if (agentPrefs.getBoolean("service_enabled", true)) {
                try {
                    val agentIntent = Intent(this, AgentService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(agentIntent)
                    else startService(agentIntent)
                } catch (_: Exception) { }
            }
        }

        enableEdgeToEdge()

        SecurityRepository.initialize(this)

        // Request runtime permissions
        val neededPerms = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            neededPerms.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            neededPerms.add(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            neededPerms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (neededPerms.isNotEmpty()) {
            permissionLauncher.launch(neededPerms.toTypedArray())
        }

        // Start background security service
        try {
            val serviceIntent = Intent(this, AgentService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } catch (e: Exception) {
            // Service startup handled gracefully
        }

        // Initial telemetry scan
        val telMgr = TelemetryManager(this)
        SecurityRepository.updateTelemetry(telMgr.gatherTelemetry())

        setContent {
            MyApplicationTheme(darkTheme = true) {
                MainAppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppRoot() {
    var currentTab by remember { mutableStateOf(MainNavTab.DASHBOARD) }
    val isSirenActive by SecurityRepository.isSirenActive.collectAsState()
    val settings by SecurityRepository.settings.collectAsState()
    val snapshots by SecurityRepository.snapshots.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    val permissionHelper = remember { PermissionHelper(context) }
    var showInitialSetupDialog by remember { mutableStateOf(!permissionHelper.areAllPermissionsGranted()) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .background(CyberCyanPrimary.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = CyberCyanPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "CLIENT AGENT",
                                color = Color.White,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp
                            )
                            Text(
                                text = if (settings.antiTheftArmed) "DEVICE SHIELD • ENDPOINT AGENT" else "SHIELD DISARMED",
                                color = if (settings.antiTheftArmed) CyberSuccessGreen else CyberWarningAmber,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                },
                actions = {
                    val backgroundClearContext = androidx.compose.ui.platform.LocalContext.current
                    androidx.compose.material3.Button(
                        onClick = {
                            backgroundClearContext.startActivity(
                                android.content.Intent(backgroundClearContext, BackgroundClearActivity::class.java)
                            )
                        }
                    ) { Text("Clear Background") }
                    // Quick Siren Button in Top Bar (Background sound only, no turn-off option on client, no notification)
                    IconButton(
                        onClick = {
                            if (!isSirenActive) {
                                SirenManager.startSiren(context)
                            }
                        },
                        modifier = Modifier.testTag("top_bar_siren_btn")
                    ) {
                        Icon(
                            imageVector = if (isSirenActive) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                            contentDescription = "Siren Status",
                            tint = if (isSirenActive) CyberAlertCrimson else CyberTextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberNavyDark,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CyberSurfaceDark,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                MainNavTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            if (tab == MainNavTab.VAULT && snapshots.isNotEmpty()) {
                                BadgedBox(
                                    badge = {
                                        Badge(containerColor = CyberAlertCrimson) {
                                            Text(
                                                text = "${snapshots.size}",
                                                color = Color.White,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                ) {
                                    Icon(imageVector = tab.icon, contentDescription = tab.title)
                                }
                            } else {
                                Icon(imageVector = tab.icon, contentDescription = tab.title)
                            }
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00363D),
                            selectedTextColor = CyberCyanPrimary,
                            indicatorColor = CyberCyanPrimary,
                            unselectedIconColor = CyberTextMuted,
                            unselectedTextColor = CyberTextMuted
                        )
                    )
                }
            }
        },
        containerColor = CyberNavyDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainNavTab.DASHBOARD -> AgentDashboardScreen(
                    onNavigateToDiagnostics = { currentTab = MainNavTab.DIAGNOSTICS },
                    onNavigateToAntiTheft = { currentTab = MainNavTab.ANTI_THEFT },
                    onNavigateToAuditLog = { currentTab = MainNavTab.LOGS }
                )
                MainNavTab.ANTI_THEFT -> AntiTheftScreen()
                MainNavTab.DIAGNOSTICS -> DiagnosticsScreen()
                MainNavTab.VAULT -> IntruderVaultScreen()
                MainNavTab.LOGS -> AuditLogScreen()
            }
        }

        if (showInitialSetupDialog) {
            MdmPermissionDialog(
                onDismiss = { showInitialSetupDialog = false },
                onPermissionsUpdated = {
                    if (permissionHelper.areAllPermissionsGranted()) {
                        showInitialSetupDialog = false
                    }
                }
            )
        }
    }
}
