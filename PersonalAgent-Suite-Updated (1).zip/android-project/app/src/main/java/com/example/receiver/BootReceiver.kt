package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.manager.SecurityRepository
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.service.AgentService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val bootActions = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_REBOOT,
            Intent.ACTION_USER_PRESENT
        )

        if (bootActions.contains(action)) {
            try {
                SecurityRepository.initialize(context)
                SecurityRepository.logEvent(
                    title = "Device Booted (Auto-Start)",
                    description = "System boot completed ($action). Resuming background security agent monitoring.",
                    severity = EventSeverity.INFO,
                    type = EventType.ADMIN_STATUS
                )

                // Start background foreground service immediately
                val serviceIntent = Intent(context, AgentService::class.java).apply {
                    putExtra("started_from_boot", true)
                    putExtra("boot_action", action)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (_: Exception) {}
        }
    }
}
