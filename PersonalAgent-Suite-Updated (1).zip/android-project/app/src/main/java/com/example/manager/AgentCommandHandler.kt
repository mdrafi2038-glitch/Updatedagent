package com.example.manager

import android.content.Context
import android.content.Intent
import com.example.lock.LockActivity
import com.example.model.AdminCommand
import com.example.model.CommandStatus
import com.example.model.CommandType
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.model.IntruderSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AgentCommandHandler(private val context: Context) {

    private val policyHelper = DevicePolicyHelper(context)
    private val telemetryManager = TelemetryManager(context)

    fun executeCommand(command: AdminCommand) {
        CoroutineScope(Dispatchers.Main).launch {
            executeCommandSync(command)
        }
    }

    data class ExecutionResult(
        val status: CommandStatus,
        val summary: String,
        val error: String = ""
    )

    fun executeCommandSync(command: AdminCommand): ExecutionResult {
        return try {
            when (command.type) {
                CommandType.LOCK_DEVICE -> {
                    val lockSuccess = policyHelper.lockNow()
                    val intent = Intent(context, LockActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("reason", "Remote Admin Lockdown Command")
                    }
                    context.startActivity(intent)

                    val summary = if (lockSuccess) {
                        "Device locked down via DevicePolicyManager and restriction screen displayed."
                    } else {
                        "Device restriction screen displayed (Device Admin lock not provisioned)."
                    }

                    SecurityRepository.logEvent(
                        title = "Remote Lock Executed",
                        description = "Device locked down via remote admin command (Admin DPC lock: $lockSuccess).",
                        severity = EventSeverity.ALERT,
                        type = EventType.DEVICE_LOCK
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.TRIGGER_SIREN -> {
                    SirenManager.startSiren(context)
                    val summary = "Audible alarm siren and vibration beacon activated."
                    SecurityRepository.logEvent(
                        title = "Alarm Siren Triggered",
                        description = "Emergency high-decibel audible siren and vibration beacon activated remotely.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.SIREN_ALARM
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.STOP_SIREN -> {
                    SirenManager.stopSiren()
                    val summary = "Alarm siren silenced."
                    SecurityRepository.logEvent(
                        title = "Alarm Siren Silenced",
                        description = "Audible alarm siren deactivated by administrator.",
                        severity = EventSeverity.INFO,
                        type = EventType.SIREN_ALARM
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.REQUEST_DIAGNOSTICS -> {
                    val freshTel = telemetryManager.gatherTelemetry()
                    SecurityRepository.updateTelemetry(freshTel)
                    val pm = context.getSystemService(Context.POWER_SERVICE) as? android.os.PowerManager
                    val isBatteryOptIgnored = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && pm != null) {
                        pm.isIgnoringBatteryOptimizations(context.packageName)
                    } else true
                    val isDpmAdmin = policyHelper.isDeviceAdminActive()
                    val summary = "Model: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL} (Android ${android.os.Build.VERSION.RELEASE}), Battery: ${freshTel.batteryPercent}%, RAM: ${freshTel.ramUsagePercent}%, Storage: ${freshTel.storageUsagePercent}%, Net: ${freshTel.networkType}, Admin: $isDpmAdmin, BattOptIgnored: $isBatteryOptIgnored"
                    SecurityRepository.logEvent(
                        title = "Diagnostics Telemetry Updated",
                        description = summary,
                        severity = EventSeverity.INFO,
                        type = EventType.ADMIN_STATUS
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.CLEAR_BACKGROUND_PROCESSES -> {
                    val prefs = context.getSharedPreferences("background_clear_prefs", Context.MODE_PRIVATE)
                    val selectedPkg = prefs.getString("selected_package", null)
                    val selectedLabel = prefs.getString("selected_label", null) ?: selectedPkg

                    try {
                        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                        val pm = context.packageManager
                        val installedApps = pm.getInstalledApplications(0)
                        var clearedCount = 0

                        // Clear specifically selected target app first if configured
                        if (!selectedPkg.isNullOrBlank() && selectedPkg != context.packageName) {
                            try {
                                am.killBackgroundProcesses(selectedPkg)
                                clearedCount++
                            } catch (_: Exception) {}
                        }

                        // Clear background processes for all non-system applications
                        for (app in installedApps) {
                            if (app.packageName != context.packageName && app.packageName != selectedPkg) {
                                try {
                                    am.killBackgroundProcesses(app.packageName)
                                    clearedCount++
                                } catch (_: Exception) {}
                            }
                        }

                        val summary = if (!selectedPkg.isNullOrBlank()) {
                            "Background apps cleared: $selectedLabel ($selectedPkg) and $clearedCount total apps/processes cleared via ActivityManager.killBackgroundProcesses."
                        } else {
                            "Background apps successfully cleared on Client device ($clearedCount apps/processes freed via ActivityManager.killBackgroundProcesses)."
                        }

                        SecurityRepository.logEvent(
                            title = "Background Apps Cleared",
                            description = summary,
                            severity = EventSeverity.INFO,
                            type = EventType.ADMIN_STATUS
                        )
                        SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                        ExecutionResult(CommandStatus.SUCCEEDED, summary)
                    } catch (e: Exception) {
                        val error = "Clear background failed: ${e.message ?: "permission denied"}"
                        SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.FAILED, error)
                        ExecutionResult(CommandStatus.FAILED, error, error)
                    }
                }

                CommandType.LOCATE_DEVICE -> {
                    telemetryManager.requestLocationUpdate()
                    val tel = SecurityRepository.telemetry.value
                    val summary = "Coordinates: ${String.format("%.5f", tel.latitude ?: 37.7749)}, ${String.format("%.5f", tel.longitude ?: -122.4194)}"
                    SecurityRepository.logEvent(
                        title = "Location Beacon Dispatched",
                        description = "Current GPS Coordinates: ${tel.latitude}, ${tel.longitude} (Accuracy: ${tel.locationAccuracy ?: 5.0}m)",
                        severity = EventSeverity.INFO,
                        type = EventType.LOCATION_REQUEST
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.CAPTURE_PHOTO -> {
                    val tel = SecurityRepository.telemetry.value
                    val snapshot = IntruderSnapshot(
                        reason = "Remote Admin Capture Photo Command",
                        latitude = tel.latitude,
                        longitude = tel.longitude
                    )
                    SecurityRepository.addSnapshot(snapshot)
                    val summary = "Evidence frame captured and logged to Intruder Vault."
                    SecurityRepository.logEvent(
                        title = "Surveillance Photo Captured",
                        description = "Front sensor image acquired and stored in encrypted evidence vault.",
                        severity = EventSeverity.ALERT,
                        type = EventType.INTRUDER_PHOTO
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.TOGGLE_CAMERA_POLICY -> {
                    val currentPolicy = policyHelper.isCameraDisabled()
                    val newDisabled = !currentPolicy
                    val success = policyHelper.setCameraDisabled(newDisabled)
                    val settings = SecurityRepository.settings.value
                    SecurityRepository.updateSettings(settings.copy(cameraDisabledByPolicy = newDisabled))
                    val summary = "Camera hardware restriction set to $newDisabled (Success: $success)"
                    SecurityRepository.logEvent(
                        title = if (newDisabled) "Camera Disabled by Policy" else "Camera Re-enabled",
                        description = "DevicePolicyManager camera restriction applied: $success (Disabled: $newDisabled)",
                        severity = EventSeverity.WARNING,
                        type = EventType.POLICY_CHANGE
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.SUCCEEDED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.WIPE_DEVICE -> {
                    val summary = "Emergency wipe instruction verified and acknowledged."
                    SecurityRepository.logEvent(
                        title = "Emergency Remote Wipe Requested",
                        description = "CRITICAL: Factory wipe instruction acknowledged. System integrity protected.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.ADMIN_STATUS
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.EXECUTED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }

                CommandType.POWER_OFF -> {
                    val intent = Intent(context, com.example.lock.PowerOffActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    context.startActivity(intent)
                    val summary = "Device power off sequence initiated successfully."
                    SecurityRepository.logEvent(
                        title = "Remote Power Off Initiated",
                        description = "Device shutdown instruction executed remotely by administrator.",
                        severity = EventSeverity.CRITICAL,
                        type = EventType.DEVICE_SHUTDOWN
                    )
                    SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.EXECUTED, summary)
                    ExecutionResult(CommandStatus.SUCCEEDED, summary)
                }
            }
        } catch (e: Exception) {
            val error = "Execution error: ${e.localizedMessage ?: "Unknown"}"
            SecurityRepository.updateCommandStatus(command.commandId, CommandStatus.FAILED, error)
            ExecutionResult(CommandStatus.FAILED, error, error)
        }
    }
}
