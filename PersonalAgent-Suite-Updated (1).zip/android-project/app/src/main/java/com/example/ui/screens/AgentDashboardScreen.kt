package com.example.ui.screens

import com.example.ui.components.PairingPanel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.lock.LockActivity
import com.example.manager.AgentCommandHandler
import com.example.manager.DevicePolicyHelper
import com.example.manager.PermissionHelper
import com.example.manager.SecurityRepository
import com.example.manager.SirenManager
import com.example.manager.TelemetryManager
import com.example.ui.components.MdmPermissionDialog
import com.example.model.AdminCommand
import com.example.model.CommandType
import com.example.model.EventSeverity
import com.example.model.EventType
import kotlinx.coroutines.delay
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberNavyDark
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariantDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarningAmber
import kotlinx.coroutines.launch

@Composable
fun AgentDashboardScreen(
    onNavigateToDiagnostics: () -> Unit,
    onNavigateToAntiTheft: () -> Unit,
    onNavigateToAuditLog: () -> Unit
) {
    val context = LocalContext.current
    val telemetry by SecurityRepository.telemetry.collectAsState()
    val settings by SecurityRepository.settings.collectAsState()
    val isSirenActive by SecurityRepository.isSirenActive.collectAsState()
    val events by SecurityRepository.events.collectAsState()
    val policyHelper = rememberCoroutineScope().let { DevicePolicyHelper(context) }
    val isAdminActive = policyHelper.isAdminActive()

    val coroutineScope = rememberCoroutineScope()
    val commandHandler = remember { AgentCommandHandler(context) }
    val telemetryManager = remember { TelemetryManager(context) }
    val permissionHelper = remember { PermissionHelper(context) }

    var permissionsAllGranted by remember { mutableStateOf(permissionHelper.areAllPermissionsGranted()) }
    var showMdmDialog by remember { mutableStateOf(false) }
    var showWipeConfirmDialog by remember { mutableStateOf(false) }
    var showPowerOffConfirmDialog by remember { mutableStateOf(false) }
    var isSimulatingWipe by remember { mutableStateOf(false) }
    var wipeProgress by remember { mutableStateOf(0f) }
    var showLocateDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberNavyDark)
            .testTag("agent_dashboard_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { PairingPanel(isAdmin = false) }
        // Hero Cyber Banner Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(BorderStroke(1.dp, CyberCyanPrimary.copy(alpha = 0.4f)), RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hero_security_banner),
                    contentDescription = "Cybersecurity Shield Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, CyberNavyDark.copy(alpha = 0.88f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(
                                    color = if (settings.antiTheftArmed) CyberSuccessGreen else CyberWarningAmber,
                                    shape = CircleShape
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (settings.antiTheftArmed) "AGENT SHIELD ACTIVE" else "AGENT SHIELD DISARMED",
                            color = if (settings.antiTheftArmed) CyberSuccessGreen else CyberWarningAmber,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.2.sp
                        )
                    }
                    Text(
                        text = "Private Agent Defense",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "${telemetry.deviceModel} • Android ${telemetry.androidVersion}",
                        color = CyberTextSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // MDM & Permissions Authorization Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("mdm_permission_banner"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(
                    1.dp,
                    if (permissionsAllGranted) CyberSuccessGreen.copy(alpha = 0.5f) else CyberWarningAmber.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    if (permissionsAllGranted) CyberSuccessGreen.copy(alpha = 0.15f) else CyberWarningAmber.copy(alpha = 0.15f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (permissionsAllGranted) Icons.Default.CheckCircle else Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = if (permissionsAllGranted) CyberSuccessGreen else CyberWarningAmber,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (permissionsAllGranted) "MDM & Permissions Authorized" else "MDM & Device Permissions Required",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (permissionsAllGranted) "All device access granted for remote commands" else "Grant all access so lock, wipe, locate & power off work",
                                color = CyberTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Button(
                        onClick = { showMdmDialog = true },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (permissionsAllGranted) Color(0xFF0F2B20) else CyberCyanPrimary
                        ),
                        border = if (permissionsAllGranted) BorderStroke(1.dp, CyberSuccessGreen) else null,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("open_mdm_permission_dialog_btn")
                    ) {
                        Text(
                            text = if (permissionsAllGranted) "Review" else "Authorize",
                            color = if (permissionsAllGranted) CyberSuccessGreen else Color(0xFF00363D),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Device Admin Status Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_status_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                border = BorderStroke(
                    1.dp,
                    if (isAdminActive) CyberSuccessGreen.copy(alpha = 0.5f) else CyberWarningAmber.copy(alpha = 0.6f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    color = if (isAdminActive) CyberSuccessGreen.copy(alpha = 0.15f) else CyberWarningAmber.copy(alpha = 0.15f),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isAdminActive) Icons.Default.AdminPanelSettings else Icons.Default.Warning,
                                contentDescription = null,
                                tint = if (isAdminActive) CyberSuccessGreen else CyberWarningAmber,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = if (isAdminActive) "Device Admin Granted" else "Admin Privileges Required",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (isAdminActive) "DPC enforcement & remote lock enabled" else "Activate to unlock hardware lock & policy control",
                                color = CyberTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    if (!isAdminActive) {
                        Button(
                            onClick = {
                                try {
                                    context.startActivity(policyHelper.getAdminActivationIntent())
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not open admin setup", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("activate_admin_button")
                        ) {
                            Text("Activate", color = Color(0xFF00363D), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .background(CyberSuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text("ACTIVE", color = CyberSuccessGreen, fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        // Remote Actions Section
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("remote_actions_section")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "REMOTE ACTIONS",
                        color = CyberCyanPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    Box(
                        modifier = Modifier
                            .background(CyberCyanPrimary.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SIMULATED COMMANDS",
                            color = CyberCyanPrimary,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 0.8.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Simulated Security Controls",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Trigger simulated enterprise security actions to verify device policy enforcement.",
                    color = CyberTextSecondary,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Lock Device Button
                    RemoteActionButton(
                        title = "Lock Device",
                        subtitle = "Force lock screen",
                        icon = Icons.Default.Lock,
                        accentColor = CyberShieldSecondary,
                        testTag = "remote_action_lock",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val cmd = AdminCommand(type = CommandType.LOCK_DEVICE, targetDeviceId = "local_device")
                            SecurityRepository.addCommand(cmd)
                            commandHandler.executeCommand(cmd)
                            Toast.makeText(context, "Simulated: Lock Device Triggered", Toast.LENGTH_SHORT).show()
                        }
                    )

                    // Power Off Button
                    RemoteActionButton(
                        title = "Power Off",
                        subtitle = "Simulate shutdown",
                        icon = Icons.Default.PowerSettingsNew,
                        accentColor = CyberAlertCrimson,
                        testTag = "remote_action_power_off",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            showPowerOffConfirmDialog = true
                        }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Locate Device Button
                    RemoteActionButton(
                        title = "Locate Device",
                        subtitle = "Query GPS beacon",
                        icon = Icons.Default.MyLocation,
                        accentColor = CyberCyanPrimary,
                        testTag = "remote_action_locate",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val cmd = AdminCommand(type = CommandType.LOCATE_DEVICE, targetDeviceId = "local_device")
                            SecurityRepository.addCommand(cmd)
                            commandHandler.executeCommand(cmd)
                            telemetryManager.requestLocationUpdate()
                            showLocateDialog = true
                            Toast.makeText(context, "Simulated: Locating Device...", Toast.LENGTH_SHORT).show()
                        }
                    )

                    // Wipe Data Button
                    RemoteActionButton(
                        title = "Wipe Data",
                        subtitle = "Simulate factory reset",
                        icon = Icons.Default.DeleteForever,
                        accentColor = CyberWarningAmber,
                        testTag = "remote_action_wipe",
                        modifier = Modifier.weight(1f),
                        onClick = {
                            showWipeConfirmDialog = true
                        }
                    )
                }
            }
        }

        // Quick Command Actions Grid
        item {
            Text(
                text = "RAPID DEFENSE CONTROLS",
                color = CyberTextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.2.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Siren Background Status (No turn-off option on client; background sound only)
                ActionTile(
                    title = if (isSirenActive) "Siren Active" else "Sound Siren",
                    subtitle = if (isSirenActive) "Background only" else "Emergency 100dB",
                    icon = Icons.Default.NotificationsActive,
                    iconColor = if (isSirenActive) CyberAlertCrimson else CyberCyanPrimary,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_siren"),
                    onClick = {
                        if (isSirenActive) {
                            // User requirement: Siren alarm off korar kono option thakbena on client
                            // Only remote admin can silence it or restart/power off
                        } else {
                            // Start siren strictly in background with NO client notification or toast
                            SirenManager.startSiren(context)
                        }
                    }
                )

                // Lock Screen Overlay Action
                ActionTile(
                    title = "Lock Overlay",
                    subtitle = "Test lock screen",
                    icon = Icons.Default.Lock,
                    iconColor = CyberShieldSecondary,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_lock"),
                    onClick = {
                        val intent = Intent(context, LockActivity::class.java).apply {
                            putExtra("reason", "Manual Test Security Lockdown")
                        }
                        context.startActivity(intent)
                    }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Anti-Theft Arm Switch
                ActionTile(
                    title = if (settings.antiTheftArmed) "Shield Armed" else "Shield Disarmed",
                    subtitle = "Anti-theft sensors",
                    icon = Icons.Default.Shield,
                    iconColor = if (settings.antiTheftArmed) CyberSuccessGreen else CyberTextMuted,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_arm"),
                    onClick = {
                        val newArm = !settings.antiTheftArmed
                        SecurityRepository.updateSettings(settings.copy(antiTheftArmed = newArm))
                        SecurityRepository.logEvent(
                            title = if (newArm) "Anti-Theft Armed" else "Anti-Theft Disarmed",
                            description = if (newArm) "Sensor protection actively monitoring." else "Sensor protection paused.",
                            severity = EventSeverity.INFO,
                            type = EventType.POLICY_CHANGE
                        )
                        Toast.makeText(context, if (newArm) "Anti-Theft Armed" else "Anti-Theft Disarmed", Toast.LENGTH_SHORT).show()
                    }
                )

                // Refresh Telemetry Action
                ActionTile(
                    title = "Scan Device",
                    subtitle = "Update diagnostics",
                    icon = Icons.Default.Refresh,
                    iconColor = CyberCyanPrimary,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("action_refresh"),
                    onClick = {
                        val telMgr = TelemetryManager(context)
                        val fresh = telMgr.gatherTelemetry()
                        SecurityRepository.updateTelemetry(fresh)
                        telMgr.requestLocationUpdate()
                        Toast.makeText(context, "Telemetry Updated", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // Live Telemetry Overview Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "HARDWARE & SECURITY POSTURE",
                    color = CyberTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "View All Diagnostics ›",
                    color = CyberCyanPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateToDiagnostics() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Battery & Power Card
                TelemetryMetricRow(
                    icon = Icons.Default.BatteryChargingFull,
                    label = "Battery & Health",
                    value = "${telemetry.batteryPercent}% (${if (telemetry.isCharging) "Charging" else "On Battery"})",
                    subValue = "Temp: ${telemetry.batteryTemperature}°C • Health: ${telemetry.batteryHealth}",
                    accentColor = if (telemetry.batteryPercent > 20) CyberSuccessGreen else CyberAlertCrimson
                )

                // Memory RAM Card
                TelemetryMetricRow(
                    icon = Icons.Default.Memory,
                    label = "System RAM Usage",
                    value = "${telemetry.ramUsagePercent}% (${telemetry.availableRamMb} MB Free)",
                    subValue = "Total: ${telemetry.totalRamMb} MB",
                    accentColor = CyberCyanPrimary,
                    progress = telemetry.ramUsagePercent / 100f
                )

                // Storage Card
                TelemetryMetricRow(
                    icon = Icons.Default.Storage,
                    label = "Internal Storage",
                    value = "${telemetry.storageUsagePercent}% (${telemetry.availableStorageGb} GB Free)",
                    subValue = "Total: ${telemetry.totalStorageGb} GB",
                    accentColor = CyberShieldSecondary,
                    progress = telemetry.storageUsagePercent / 100f
                )

                // Network Status
                TelemetryMetricRow(
                    icon = Icons.Default.Wifi,
                    label = "Network & IP",
                    value = telemetry.networkType,
                    subValue = "IP: ${telemetry.ipAddress} • SSID: ${telemetry.wifiSsid}",
                    accentColor = if (telemetry.isConnected) CyberCyanPrimary else CyberTextMuted
                )

                // Location GPS
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("telemetry_location_card"),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, CyberBorderDark)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(CyberShieldSecondary.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.MyLocation, contentDescription = null, tint = CyberShieldSecondary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("GPS Geo-Beacon", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "Lat: ${String.format("%.4f", telemetry.latitude ?: 37.7749)}, Lon: ${String.format("%.4f", telemetry.longitude ?: -122.4194)}",
                                    color = CyberTextSecondary,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                val lat = telemetry.latitude ?: 37.7749
                                val lon = telemetry.longitude ?: -122.4194
                                val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(Agent)"))
                                try {
                                    context.startActivity(mapIntent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Maps app not available", Toast.LENGTH_SHORT).show()
                                }
                            }
                        ) {
                            Icon(Icons.Default.MyLocation, contentDescription = "Open in Maps", tint = CyberCyanPrimary)
                        }
                    }
                }
            }
        }

        // Recent Security Incidents / Audit Stream
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECENT SECURITY ACTIVITY",
                    color = CyberTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Full Audit Log ›",
                    color = CyberCyanPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onNavigateToAuditLog() }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                events.take(3).forEach { evt ->
                    EventCardMini(evt)
                }
            }
        }
    }

    if (showWipeConfirmDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSimulatingWipe) showWipeConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = CyberAlertCrimson)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simulate Wipe Data", color = CyberAlertCrimson, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    if (isSimulatingWipe) {
                        Text(
                            "Simulating emergency remote wipe sequence...",
                            color = Color.White,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { wipeProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = CyberAlertCrimson,
                            trackColor = CyberSurfaceVariantDark
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "${(wipeProgress * 100).toInt()}% Completed",
                            color = CyberAlertCrimson,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    } else {
                        Text(
                            "Are you sure you want to test the 'Wipe Data' remote command? This will simulate an enterprise factory reset instruction, verify policy enforcement, and record a CRITICAL incident in the audit trail without wiping local OS files.",
                            color = CyberTextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            },
            confirmButton = {
                if (!isSimulatingWipe) {
                    Button(
                        onClick = {
                            isSimulatingWipe = true
                            wipeProgress = 0f
                            coroutineScope.launch {
                                val cmd = AdminCommand(type = CommandType.WIPE_DEVICE, targetDeviceId = "local_device")
                                SecurityRepository.addCommand(cmd)
                                for (p in 1..10) {
                                    delay(100)
                                    wipeProgress = p / 10f
                                }
                                commandHandler.executeCommand(cmd)
                                isSimulatingWipe = false
                                showWipeConfirmDialog = false
                                Toast.makeText(context, "Simulated: Wipe Data Command Completed", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberAlertCrimson),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("confirm_wipe_button")
                    ) {
                        Text("Trigger Wipe", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                if (!isSimulatingWipe) {
                    TextButton(onClick = { showWipeConfirmDialog = false }) {
                        Text("Cancel", color = CyberTextSecondary)
                    }
                }
            },
            containerColor = CyberSurfaceDark
        )
    }

    if (showLocateDialog) {
        val lat = telemetry.latitude ?: 37.7749
        val lon = telemetry.longitude ?: -122.4194
        val acc = telemetry.locationAccuracy ?: 4.5f
        val addr = telemetry.locationAddress ?: "San Francisco, CA (Geo-fence Protected)"

        AlertDialog(
            onDismissRequest = { showLocateDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MyLocation, contentDescription = null, tint = CyberCyanPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Device Located", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Simulated Remote Beacon Resolved:", color = CyberTextSecondary, fontSize = 12.sp)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF0C1222), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text("LATITUDE: ${String.format("%.5f", lat)}", color = CyberCyanPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text("LONGITUDE: ${String.format("%.5f", lon)}", color = CyberCyanPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text("ACCURACY: ±${String.format("%.1f", acc)}m", color = CyberShieldSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("ADDRESS: $addr", color = CyberTextMuted, fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showLocateDialog = false
                        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:$lat,$lon?q=$lat,$lon(Agent Device)"))
                        try {
                            context.startActivity(mapIntent)
                        } catch (e: Exception) {
                            Toast.makeText(context, "Maps application not available", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Open in Maps", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLocateDialog = false }) {
                    Text("Close", color = CyberTextSecondary)
                }
            },
            containerColor = CyberSurfaceDark
        )
    }

    if (showPowerOffConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showPowerOffConfirmDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PowerSettingsNew, contentDescription = null, tint = CyberAlertCrimson)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Simulate Power Off", color = CyberAlertCrimson, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        "Are you sure you want to test the remote Power Off sequence? This will simulate an immediate hardware shutdown, trigger haptic feedback, and display the device blackout screen.",
                        color = CyberTextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        "You can turn the device back on at any time using the on-screen physical power button.",
                        color = CyberTextMuted,
                        fontSize = 11.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showPowerOffConfirmDialog = false
                        val cmd = AdminCommand(type = CommandType.POWER_OFF, targetDeviceId = "local_device")
                        SecurityRepository.addCommand(cmd)
                        commandHandler.executeCommand(cmd)
                        Toast.makeText(context, "Power Off Sequence Initiated", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberAlertCrimson),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("confirm_power_off_btn")
                ) {
                    Text("Power Off Now", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPowerOffConfirmDialog = false }) {
                    Text("Cancel", color = CyberTextSecondary)
                }
            },
            containerColor = CyberSurfaceDark
        )
    }
}

@Composable
fun RemoteActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(accentColor.copy(alpha = 0.15f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1
            )
            Text(
                text = subtitle,
                color = CyberTextSecondary,
                fontSize = 10.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
fun ActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
        border = BorderStroke(1.dp, CyberBorderDark)
    ) {
        Column(
            modifier = Modifier.padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(iconColor.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = iconColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(text = subtitle, color = CyberTextSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
fun TelemetryMetricRow(
    icon: ImageVector,
    label: String,
    value: String,
    subValue: String,
    accentColor: Color,
    progress: Float? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
        border = BorderStroke(1.dp, CyberBorderDark)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = subValue, color = CyberTextSecondary, fontSize = 11.sp)
                    }
                }
                Text(text = value, color = accentColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }

            if (progress != null) {
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp)),
                    color = accentColor,
                    trackColor = CyberSurfaceVariantDark
                )
            }
        }
    }
}

@Composable
fun EventCardMini(event: com.example.model.SecurityEvent) {
    val accent = when (event.severity) {
        EventSeverity.INFO -> CyberCyanPrimary
        EventSeverity.WARNING -> CyberWarningAmber
        EventSeverity.ALERT -> CyberAlertCrimson
        EventSeverity.CRITICAL -> CyberAlertCrimson
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
        border = BorderStroke(1.dp, CyberBorderDark)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(accent, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = event.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    text = event.description,
                    color = CyberTextSecondary,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }
            Text(
                text = formatTimeAgo(event.timestamp),
                color = CyberTextMuted,
                fontSize = 10.sp
            )
        }
    }
}

fun formatTimeAgo(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    val mins = diff / 60000
    return when {
        mins < 1 -> "Just now"
        mins < 60 -> "${mins}m ago"
        mins < 1440 -> "${mins / 60}h ago"
        else -> "${mins / 1440}d ago"
    }
}
