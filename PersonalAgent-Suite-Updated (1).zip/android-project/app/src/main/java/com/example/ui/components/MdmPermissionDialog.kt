package com.example.ui.components

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.manager.PermissionHelper
import com.example.manager.SecurityRepository
import com.example.model.EventSeverity
import com.example.model.EventType
import com.example.ui.theme.CyberAlertCrimson
import com.example.ui.theme.CyberBorderDark
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberShieldSecondary
import com.example.ui.theme.CyberSuccessGreen
import com.example.ui.theme.CyberSurfaceDark
import com.example.ui.theme.CyberSurfaceVariantDark
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberWarningAmber

@Composable
fun MdmPermissionDialog(
    onDismiss: () -> Unit,
    onPermissionsUpdated: () -> Unit
) {
    val context = LocalContext.current
    val permissionHelper = remember { PermissionHelper(context) }

    var adminGranted by remember { mutableStateOf(permissionHelper.isDeviceAdminGranted()) }
    var locationGranted by remember { mutableStateOf(permissionHelper.isLocationGranted()) }
    var cameraGranted by remember { mutableStateOf(permissionHelper.isCameraGranted()) }
    var notifGranted by remember { mutableStateOf(permissionHelper.isNotificationsGranted()) }
    var overlayGranted by remember { mutableStateOf(permissionHelper.isOverlayGranted()) }
    var batteryGranted by remember { mutableStateOf(permissionHelper.isBatteryOptimizationIgnored()) }

    fun refreshStates() {
        adminGranted = permissionHelper.isDeviceAdminGranted()
        locationGranted = permissionHelper.isLocationGranted()
        cameraGranted = permissionHelper.isCameraGranted()
        notifGranted = permissionHelper.isNotificationsGranted()
        overlayGranted = permissionHelper.isOverlayGranted()
        batteryGranted = permissionHelper.isBatteryOptimizationIgnored()
        onPermissionsUpdated()
    }

    val grantedCount = listOf(adminGranted, locationGranted, cameraGranted, notifGranted, overlayGranted, batteryGranted).count { it }
    val totalCount = 6
    val progress = grantedCount.toFloat() / totalCount

    val runtimePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        refreshStates()
    }

    val activityLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        refreshStates()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("mdm_permission_dialog"),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(CyberCyanPrimary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = CyberCyanPrimary,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MDM & Permissions Center",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                    Text(
                        text = if (grantedCount == totalCount) "All security permissions active" else "Setup required for remote commands",
                        color = if (grantedCount == totalCount) CyberSuccessGreen else CyberWarningAmber,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Post-Install Explanation Callout
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                        .border(1.dp, CyberBorderDark, RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "INSTALLATION AUTHORIZATION",
                                color = CyberCyanPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Grant MDM (Device Admin) and phone permissions so that all remote security commands (Lock Device, Wipe Data, Locate, Siren, and Power Off) work reliably from the Admin App.",
                            color = CyberTextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                // Progress Bar Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberSurfaceDark),
                    border = BorderStroke(1.dp, if (grantedCount == totalCount) CyberSuccessGreen.copy(alpha = 0.5f) else CyberBorderDark)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Authorization Progress",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "$grantedCount / $totalCount Granted",
                                color = if (grantedCount == totalCount) CyberSuccessGreen else CyberCyanPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = if (grantedCount == totalCount) CyberSuccessGreen else CyberCyanPrimary,
                            trackColor = CyberSurfaceVariantDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Item 1: Device Admin (MDM)
                PermissionItemCard(
                    title = "Device Administrator (MDM)",
                    desc = "Authorizes remote screen lock, factory wipe & policy restrictions",
                    icon = Icons.Default.AdminPanelSettings,
                    isGranted = adminGranted,
                    onGrant = {
                        activityLauncher.launch(permissionHelper.getDeviceAdminIntent())
                    }
                )

                // Item 2: Draw Over Other Apps (Overlay)
                PermissionItemCard(
                    title = "Draw Over Apps (Overlay)",
                    desc = "Enables instant lockdown overlay and remote Power Off screen",
                    icon = Icons.Default.Layers,
                    isGranted = overlayGranted,
                    onGrant = {
                        activityLauncher.launch(permissionHelper.getOverlayIntent())
                    }
                )

                // Item 3: Precise Location (GPS)
                PermissionItemCard(
                    title = "Precise Location (GPS)",
                    desc = "Allows remote device locate command & GPS coordinate tracking",
                    icon = Icons.Default.MyLocation,
                    isGranted = locationGranted,
                    onGrant = {
                        runtimePermissionLauncher.launch(
                            arrayOf(
                                android.Manifest.permission.ACCESS_FINE_LOCATION,
                                android.Manifest.permission.ACCESS_COARSE_LOCATION
                            )
                        )
                    }
                )

                // Item 4: Camera Hardware
                PermissionItemCard(
                    title = "Camera Hardware Access",
                    desc = "Allows remote snapshot photo & intruder capture",
                    icon = Icons.Default.CameraAlt,
                    isGranted = cameraGranted,
                    onGrant = {
                        runtimePermissionLauncher.launch(arrayOf(android.Manifest.permission.CAMERA))
                    }
                )

                // Item 5: Notifications
                PermissionItemCard(
                    title = "Security Notifications",
                    desc = "Keeps persistent background protection active & alerts visible",
                    icon = Icons.Default.NotificationsActive,
                    isGranted = notifGranted,
                    onGrant = {
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                            runtimePermissionLauncher.launch(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS))
                        }
                    }
                )

                // Item 6: Battery Optimization Exemption
                PermissionItemCard(
                    title = "Unrestricted Battery Mode",
                    desc = "Prevents Android from killing agent service so remote commands always arrive",
                    icon = Icons.Default.BatteryChargingFull,
                    isGranted = batteryGranted,
                    onGrant = {
                        activityLauncher.launch(permissionHelper.getBatteryOptimizationIntent())
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val neededRuntime = mutableListOf<String>()
                    if (!locationGranted) {
                        neededRuntime.add(android.Manifest.permission.ACCESS_FINE_LOCATION)
                        neededRuntime.add(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                    }
                    if (!cameraGranted) {
                        neededRuntime.add(android.Manifest.permission.CAMERA)
                    }
                    if (!notifGranted && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                        neededRuntime.add(android.Manifest.permission.POST_NOTIFICATIONS)
                    }

                    if (neededRuntime.isNotEmpty()) {
                        runtimePermissionLauncher.launch(neededRuntime.toTypedArray())
                    } else if (!adminGranted) {
                        activityLauncher.launch(permissionHelper.getDeviceAdminIntent())
                    } else if (!overlayGranted) {
                        activityLauncher.launch(permissionHelper.getOverlayIntent())
                    } else if (!batteryGranted) {
                        activityLauncher.launch(permissionHelper.getBatteryOptimizationIntent())
                    } else {
                        Toast.makeText(context, "All MDM and device permissions verified!", Toast.LENGTH_SHORT).show()
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (grantedCount == totalCount) CyberSuccessGreen else CyberCyanPrimary
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag("grant_all_permissions_btn")
            ) {
                if (grantedCount == totalCount) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00363D), modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("All Granted • Done", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                } else {
                    Text("Grant Next Permission", color = Color(0xFF00363D), fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (grantedCount == totalCount) "Close" else "Later", color = CyberTextSecondary)
            }
        },
        containerColor = CyberSurfaceDark
    )
}

@Composable
fun PermissionItemCard(
    title: String,
    desc: String,
    icon: ImageVector,
    isGranted: Boolean,
    onGrant: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0B1020)),
        border = BorderStroke(
            1.dp,
            if (isGranted) CyberSuccessGreen.copy(alpha = 0.4f) else CyberBorderDark
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .background(
                            if (isGranted) CyberSuccessGreen.copy(alpha = 0.15f) else CyberWarningAmber.copy(alpha = 0.15f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isGranted) CyberSuccessGreen else CyberWarningAmber,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Text(desc, color = CyberTextSecondary, fontSize = 10.sp, lineHeight = 13.sp)
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            if (isGranted) {
                Box(
                    modifier = Modifier
                        .background(CyberSuccessGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text("ACTIVE", color = CyberSuccessGreen, fontSize = 9.sp, fontWeight = FontWeight.Black)
                }
            } else {
                OutlinedButton(
                    onClick = onGrant,
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, CyberCyanPrimary),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("Grant", color = CyberCyanPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

